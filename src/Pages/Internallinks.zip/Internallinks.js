import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import '../Css/File.css';
import { Pie, Bar } from 'react-chartjs-2';
import 'chart.js/auto'; // Correct import for Chart.js version 3 and above
import CircularProgress from '@material-ui/core/CircularProgress'; // Import CircularProgress from Material-UI
import { makeStyles } from '@material-ui/core/styles'; 
import 'sweetalert2/src/sweetalert2.scss'; // Import SweetAlert styles



const useStyles = makeStyles((theme) => ({
  spinner: {
    color: '#36A2EB', // Customize the color of the spinner
    marginTop: theme.spacing(2), // Adjust the margin top as needed
  },
}));

  const InternalLinkCounter = () => {
    const classes = useStyles(); // Define classes using makeStyles

  const [url, setUrl] = useState('');
  const [internalLinksCount, setInternalLinksCount] = useState(null);
  const [externalLinksCount, setExternalLinksCount] = useState(null);
  const [metaTagsCount, setMetaTagsCount] = useState(null);
  const [backlinksCount, setBacklinksCount] = useState(null);
  const [internalLinks, setInternalLinks] = useState([]);
  const [externalLinks, setExternalLinks] = useState([]);
  const [totalCrawledLinks, setTotalCrawledLinks] = useState(null);
  const [htmlPagesCount, setHtmlPagesCount] = useState(null);
  const [nonHtmlFilesCount, setNonHtmlFilesCount] = useState(null);
  const [redirects, setRedirects] = useState([]);
  const [brokenLinks, setBrokenLinks] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [showLinks, setShowLinks] = useState(null); // State to control which links to display

  const [httpLinksCount, setHttpLinksCount] = useState(0);
  const [httpsLinksCount, setHttpsLinksCount] = useState(0);

  const brokenLinksChartRef = useRef(null);
  const htmlPagesChartRef = useRef(null);
  const redirectsChartRef = useRef(null);
  const protocolChartRef = useRef(null);
  const barChartRef = useRef(null);
  const [elapsedTime, setElapsedTime] = useState(0); // State for tracking elapsed time

  const timerRef = useRef(null); // Reference for the timer
  useEffect(() => {
    if (!url) return;

    setLoading(true);

    axios.get(`http://localhost:8000/count-internal-links/?url=${encodeURIComponent(url)}`)
      .then(response => {
        const {
          internal_links_count,
          external_links_count,
          meta_tags_count,
          backlinks_count,
          internal_links,
          external_links,
          total_crawled_links,
          html_pages_count,
          non_html_files_count,
          redirects,
          broken_links
        } = response.data;

        setInternalLinksCount(internal_links_count);
        setExternalLinksCount(external_links_count);
        setMetaTagsCount(meta_tags_count);
        setBacklinksCount(backlinks_count);
        setInternalLinks(internal_links);
        setExternalLinks(external_links);
        setTotalCrawledLinks(total_crawled_links);
        setHtmlPagesCount(html_pages_count);
        setNonHtmlFilesCount(non_html_files_count);
        setRedirects(redirects);
        setBrokenLinks(broken_links);

        // Calculate HTTP and HTTPS links count
        const httpLinks = internal_links.filter(link => link.startsWith('http://')).length +
                          external_links.filter(link => link.startsWith('http://')).length;
        const httpsLinks = internal_links.filter(link => link.startsWith('https://')).length +
                           external_links.filter(link => link.startsWith('https://')).length;

        setHttpLinksCount(httpLinks);
        setHttpsLinksCount(httpsLinks);

        setError(null);
      })
      .catch(error => {
        setError(error.response ? error.response.data.error : 'An error occurred');
        setInternalLinksCount(null);
        setExternalLinksCount(null);
        setMetaTagsCount(null);
        setBacklinksCount(null);
        setInternalLinks([]);
        setExternalLinks([]);
        setTotalCrawledLinks(null);
        setHtmlPagesCount(null);
        setNonHtmlFilesCount(null);
        setRedirects([]);
        setBrokenLinks([]);
        setHttpLinksCount(0);
        setHttpsLinksCount(0);
      })
      .finally(() => {
        setLoading(false);
        setElapsedTime(0); // Reset the elapsed time

      });
  }, [url]);

  // Start the timer
  timerRef.current = setInterval(() => {
    setElapsedTime(prevTime => prevTime + 100); // Update the elapsed time every 100ms
  }, 100);

  const handleSearch = () => {
    setInternalLinksCount(null);
    setExternalLinksCount(null);
    setMetaTagsCount(null);
    setBacklinksCount(null);
    setError(null);
    setInternalLinks([]);
    setExternalLinks([]);
    setTotalCrawledLinks(null);
    setHtmlPagesCount(null);
    setNonHtmlFilesCount(null);
    setRedirects([]);
    setBrokenLinks([]);
    setHttpLinksCount(0);
    setHttpsLinksCount(0);

    setUrl(document.getElementById('urlInput').value);
  };

  useEffect(() => {
    // Cleanup function to destroy chart instances if they exist
    return () => {
      if (brokenLinksChartRef.current && brokenLinksChartRef.current.chartInstance) {
        brokenLinksChartRef.current.chartInstance.destroy();
      }
      if (htmlPagesChartRef.current && htmlPagesChartRef.current.chartInstance) {
        htmlPagesChartRef.current.chartInstance.destroy();
      }
      if (redirectsChartRef.current && redirectsChartRef.current.chartInstance) {
        redirectsChartRef.current.chartInstance.destroy();
      }
      if (protocolChartRef.current && protocolChartRef.current.chartInstance) {
        protocolChartRef.current.chartInstance.destroy();
      }
      if (barChartRef.current && barChartRef.current.chartInstance) {
        barChartRef.current.chartInstance.destroy();
      }
    };
  }, [brokenLinks, htmlPagesCount, nonHtmlFilesCount, redirects, httpLinksCount, httpsLinksCount]);

  // Data for Pie Charts
  const brokenLinksData = {
    labels: ['Broken Links', 'Non-Broken Links'],
    datasets: [
      {
        data: [brokenLinks.length, internalLinks.length + externalLinks.length - brokenLinks.length],
        backgroundColor: ['#FF6347', '#36A2EB'],
      },
    ],
  };

  const htmlPagesData = {
    labels: ['HTML Pages', 'Non-HTML Files'],
    datasets: [
      {
        data: [htmlPagesCount, nonHtmlFilesCount],
        backgroundColor: ['#FFD700', '#ADFF2F'],
      },
    ],
  };

  const redirectsData = {
    labels: ['Redirect Links', 'Non-Redirect Links'],
    datasets: [
      {
        data: [redirects.length, internalLinks.length + externalLinks.length - redirects.length],
        backgroundColor: ['#FFA500', '#9932CC'],
      },
    ],
  };

  const protocolData = {
    labels: ['HTTP Links', 'HTTPS Links'],
    datasets: [
      {
        data: [httpLinksCount, httpsLinksCount],
        backgroundColor: ['#FF4500', '#00FF00'],
      },
    ],
  };

  // Data for Bar Chart
  const barData = {
    labels: ['Internal Links', 'External Links', 'Meta Tags', 'Backlinks', 'Total Crawled Links', 'HTML Pages', 'Non-HTML Files', 'Redirects', 'Broken Links', 'HTTP Links', 'HTTPS Links'],
    datasets: [
      {
        label: 'Count',
        data: [
          internalLinksCount,
          externalLinksCount,
          metaTagsCount,
          backlinksCount,
          totalCrawledLinks,
          htmlPagesCount,
          nonHtmlFilesCount,
          redirects.length,
          brokenLinks.length,
          httpLinksCount,
          httpsLinksCount
        ],
        backgroundColor: [
          '#36A2EB',
          '#ADD53A',
          '#B30EC1',
          '#36A2EB',
          '#00FF00',
          '#FFD700',
          '#ADFF2F',
          '#EAF908',
          '#F5250C',
          '#FF4500',
          '#00FF00'
        ],
      },
    ],
  };

  const renderLinks = (links) => (
    <ul>
      {links.map((link, index) => (
        <li key={index}><a href={link} target="_blank" rel="noopener noreferrer">{link}</a></li>
      ))}
    </ul>
  );


  // Calculate minutes, seconds, and milliseconds from elapsed time
  const minutes = Math.floor(elapsedTime / 60000);
  const seconds = Math.floor((elapsedTime % 60000) / 1000);
  const milliseconds = elapsedTime % 1000;




  return (
    <div>
      <h3>Internal Pages</h3>
      <label htmlFor="urlInput" className="label">Enter URL:</label>
      <input type="url" id="urlInput" className="input" required />
      <button onClick={handleSearch} className="button">Search</button>
      {loading && <CircularProgress className={classes.spinner} />} {/* Apply custom styles to CircularProgress */}
      {error && <p className="error">Error: {error}</p>}
      {!loading && (
        <div className="row">
          {internalLinksCount !== null && (
            <div className="col-md-3">
              <div className="card" onClick={() => setShowLinks('internal')}>
                <div className="card-body">
                  <p style={{ color: '#36A2EB' }}>Internal Links</p>
                  <p className="card-text">{internalLinksCount}</p>
                </div>
              </div>
            </div>
          )}
          {externalLinksCount !== null && (
            <div className="col-md-3">
              <div className="card" onClick={() => setShowLinks('external')}>
                <div className="card-body">
                  <p style={{ color: '#36A2EB' }}>External Links</p>
                  <p className="card-text">{externalLinksCount}</p>
                </div>
              </div>
            </div>
          )}
          {metaTagsCount !== null && (
            <div className="col-md-3">
              <div className="card">
                <div className="card-body">
                  <p style={{ color: '#36A2EB' }}>Meta Tags</p>
                  <p className="card-text">{metaTagsCount}</p>
                </div>
              </div>
            </div>
          )}
          {backlinksCount !== null && (
            <div className="col-md-3">
              <div className="card">
                <div className="card-body">
                  <p style={{ color: '#36A2EB' }}>Backlinks</p>
                  <p className="card-text">{backlinksCount}</p>
                </div>
              </div>
            </div>
          )}
          {totalCrawledLinks !== null && (
            <div className="col-md-3">
              <div className="card">
                <div className="card-body">
                  <p style={{ color: '#36A2EB' }}>Total Crawled Links</p>
                  <p className="card-text">{totalCrawledLinks}</p>
                </div>
              </div>
            </div>
          )}
          {htmlPagesCount !== null && (
            <div className="col-md-3">
              <div className="card">
                <div className="card-body">
                  <p style={{ color: '#36A2EB' }}>HTML Pages</p>
                  <p className="card-text">{htmlPagesCount}</p>
                </div>
              </div>
            </div>
          )}
          {nonHtmlFilesCount !== null && (
            <div className="col-md-3">
              <div className="card">
                <div className="card-body">
                  <p style={{ color: '#36A2EB' }}>Non-HTML Files</p>
                  <p className="card-text">{nonHtmlFilesCount}</p>
                </div>
              </div>
            </div>
          )}
          {redirects.length > 0 && (
            <div className="col-md-3">
              <div className="card">
                <div className="card-body">
                  <p style={{ color: '#36A2EB' }}>Redirects</p>
                  <p className="card-text">{redirects.length}</p>
                </div>
              </div>
            </div>
          )}
          {brokenLinks.length > 0 && (
            <div className="col-md-3">
              <div className="card">
                <div className="card-body">
                  <p style={{ color: '#36A2EB' }}>Broken Links</p>
                  <p className="card-text">{brokenLinks.length}</p>
                </div>
              </div>
            </div>
          )}
          {httpLinksCount + httpsLinksCount > 0 && (
            <div className="col-md-3">
              <div className="card">
                <div className="card-body">
                  <p style={{ color: '#36A2EB' }}>HTTP Links</p>
                  <p className="card-text">{httpLinksCount}</p>
                </div>
              </div>
              <div className="card">
                <div className="card-body">
                  <p style={{ color: '#36A2EB' }}>HTTPS Links</p>
                  <p className="card-text">{httpsLinksCount}</p>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
      <div className="row">
        <div className="col-md-5">
          <div className="card">
            <div className="card-body">
              <h5 className="card-title">Broken Links</h5>
              <Pie data={brokenLinksData} ref={brokenLinksChartRef} />
            </div>
          </div>
        </div>
        <div className="col-md-5">
          <div className="card">
            <div className="card-body">
              <h6 className="card-title">HTML Pages vs Non-HTML Files</h6>
              <Pie data={htmlPagesData} ref={htmlPagesChartRef} />
            </div>
          </div>
        </div>
        <div className="col-md-5">
          <div className="card">
            <div className="card-body">
              <h5 className="card-title">Redirects</h5>
              <Pie data={redirectsData} ref={redirectsChartRef} />
            </div>
          </div>
        </div>
        <div className="col-md-5">
          <div className="card">
            <div className="card-body">
              <h5 className="card-title">HTTP vs HTTPS Links</h5>
              <Pie data={protocolData} ref={protocolChartRef} />
            </div>
          </div>
        </div>



            <div className="col-md-5">
          <div className="card">
            <div className="card-body">
              <h5 className="card-title">Protocol Distribution
              </h5>
              <Pie data={protocolData} ref={protocolChartRef} />
              </div>
          </div>
        </div>

        
        <div className="col-md-10">
          <div className="card">
            <div className="card-body">
              <h5 className="card-title">All Types of Links</h5>
              <Bar data={barData} ref={barChartRef} />
            </div>
          </div>
        </div>
      </div>
      <div>
        {showLinks === 'internal' && (
          <div>
            <h4>Internal Links</h4>
            {renderLinks(internalLinks)}
          </div>
        )}
        {showLinks === 'external' && (
          <div>
            <h4>External Links</h4>
            {renderLinks(externalLinks)}
          </div>
        )}
      </div>
    </div>
  );
};

export default InternalLinkCounter;
