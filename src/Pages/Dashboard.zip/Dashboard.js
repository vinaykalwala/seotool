import * as React from 'react';
import { styled, useTheme } from '@mui/material/styles';
import Box from '@mui/material/Box';
import Drawer from '@mui/material/Drawer';
import CssBaseline from '@mui/material/CssBaseline';
import MuiAppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import List from '@mui/material/List';
import Typography from '@mui/material/Typography';
import Divider from '@mui/material/Divider';
import IconButton from '@mui/material/IconButton';
import MenuIcon from '@mui/icons-material/Menu';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import SettingsIcon from '@mui/icons-material/Settings'; // Add this import
import ArrowBackIcon from '@mui/icons-material/ArrowBack'; // Add this import
import SpeedIcon from '@mui/icons-material/Speed'; // Add this import

import { 
  ListItem, ListItemButton, ListItemIcon, ListItemText, 
  Accordion, AccordionSummary, AccordionDetails 
} from '@mui/material';
import { Link } from 'react-router-dom';
import DescriptionIcon from '@mui/icons-material/Description';
import LinkIcon from '@mui/icons-material/Link';
import SearchIcon from '@mui/icons-material/Search';
import ImageIcon from '@mui/icons-material/Image';
import ErrorIcon from '@mui/icons-material/Error';
import TitleIcon from '@mui/icons-material/Title';
import AssessmentIcon from '@mui/icons-material/Assessment';
import BuildIcon from '@mui/icons-material/Build';
import SocialDistanceIcon from '@mui/icons-material/SocialDistance';
import AssignmentIcon from '@mui/icons-material/Assignment';
import LanguageIcon from '@mui/icons-material/Language';
import ExploreIcon from '@mui/icons-material/Explore';
import LinkOffIcon from '@mui/icons-material/LinkOff';
import '../App.css'; // Ensure your CSS is correctly imported
import logo from '../assets/logo.png';
import KeywordResearch from './KeywordResearch';
import Button from '@mui/material/Button';
import { useNavigate } from 'react-router-dom';
import { Route, Routes } from 'react-router-dom';
import FullContent from './Fullcontent';
import Sitemap from './Sitemap';
import Urlanalyser from './Urlanalyser';
import Indexibility from './Indexibility';
import Status200Links from '../Pages/Status200Links';
import Socialtags from '../Pages/Socialtags';
import Directives from '../Pages/Directives';
import Imageresource from './Imageresource';
import KeywordSuggestion from '../Pages/Keywordsuggesstion';
import WesiteAnalysLinks from '../Pages/Websiteanalysislinks';
import Canonicallinks from './Canonicallinks';
import Brokenimages from './Brokenimages';
import Title from './Title';
import Errorlinks from '../Pages/Error';
import Headings from './Headings';
import DoFollow from '../Pages/Dofollowlinks';
import Internallinks from './Internallinks'; // Make sure this component is imported correctly
import Crawedlinks from './Crawedlinks';
import Imagelinks from './Imagelinks';
import AddKeyword from '../Components/AddKeyword';
import AnalyzePage from '../Components/AnalyzePage';
import Externallinks from '../Pages/Externallinks';
import Backlinks from '../Pages/Backlinks';
import DefaultDashboardContent from '../Pages/DefaultDashboardContent';

const drawerWidth = 240;
const Main = styled(Box, { shouldForwardProp: (prop) => prop !== 'open' })(
  ({ theme, open }) => ({
    flexGrow: 1,
    padding: theme.spacing(3),
    transition: theme.transitions.create('margin', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    marginLeft: `-${drawerWidth}px`,
    ...(open && {
      transition: theme.transitions.create('margin', {
        easing: theme.transitions.easing.easeOut,
        duration: theme.transitions.duration.enteringScreen,
      }),
      marginLeft: 30,
    }),
  }),
);

const AppBar = styled(MuiAppBar, {
  shouldForwardProp: (prop) => prop !== 'open',
})(({ theme, open }) => ({
  transition: theme.transitions.create(['margin', 'width'], {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  ...(open && {
    width: `calc(100% - ${drawerWidth}px)`,
    marginLeft: `${drawerWidth}px`,
    transition: theme.transitions.create(['margin', 'width'], {
      easing: theme.transitions.easing.easeOut,
      duration: theme.transitions.duration.enteringScreen,
    }),
  }),
}));

const DrawerHeader = styled('div')(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  padding: theme.spacing(0, 1),
  ...theme.mixins.toolbar,
  justifyContent: 'flex-end',
}));

export default function PersistentDrawerLeft() {
  const theme = useTheme();
  const [open, setOpen] = React.useState(false);
  const [expanded, setExpanded] = React.useState(false); // Define expanded state

  const handleDrawerOpen = () => {
    setOpen(true);
  };

  const handleDrawerClose = () => {
    setOpen(false);
  };
  
  const handleUpgradeClick = () => {
    navigate('/pricing'); // Navigate to /pricing route
  };

  const handleChange = (panel) => (event, isExpanded) => { // Define handleChange function
    setExpanded(isExpanded ? panel : false);
  };

  const navigate = useNavigate();

  return (
    <Box sx={{ display: 'flex' }}>
      <CssBaseline />
      <AppBar position="fixed" open={open} sx={{ backgroundColor: 'rgb(37, 80, 123)' }}>
        <Toolbar>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            onClick={handleDrawerOpen}
            edge="start"
            sx={{ mr: 2, ...(open && { display: 'none' }) }}
          >
            <MenuIcon />
          </IconButton>
          <Box sx={{ flexGrow: 1 }}>
            <Typography variant="h6" noWrap component="div" sx={{ color: 'white' }}>
              Seo Dashboard
            </Typography>
          </Box>
          <button className="button-17" onClick={handleUpgradeClick} role="button">
            UpGrade now
          </button>
        </Toolbar>
      </AppBar>
      <Drawer
        sx={{
          width: drawerWidth,
          flexShrink: 0,
          '& .MuiDrawer-paper': {
            width: drawerWidth,
            boxSizing: 'border-box',
          },
        }}
        variant="persistent"
        anchor="left"
        open={open}
      >
    <DrawerHeader sx={{ backgroundColor: 'rgb(37, 80, 123)', padding: '16px', display: 'flex', alignItems: 'center' }}>
  <Typography variant="h6" component="div" sx={{ flexGrow: 1, color: '#fff' }}>
    <h1 className='logo'>SEO</h1>
  </Typography>
  <IconButton onClick={handleDrawerClose} style={{ color: 'white' }}>
    {theme.direction === 'ltr' ? <ChevronLeftIcon style={{ color: 'white' }} /> : <ChevronRightIcon style={{ color: 'white' }} />}
  </IconButton>
</DrawerHeader>









<List sx={{ backgroundColor: 'rgb(37, 80, 123)' }}>
        {/* Internal Links Accordion */}

        <Accordion 
          expanded={expanded === 'fullcontent'} 
          onChange={handleChange('fullcontent')}
          className="accordion"
          style={{ backgroundColor: 'rgb(37, 80, 123)' }}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon sx={{ color: 'white' }} />}
            aria-controls="fullcontent-content"
            id="fullcontent-header"
            className="accordion-summary"
          >
            <ListItemIcon className="accordion-icon" style={{ color: '#fff' }}>
              <DescriptionIcon />
            </ListItemIcon>
            <ListItemText className="usha" primary="fullcontent Links" />
          </AccordionSummary>
          <AccordionDetails className="accordion-details">
            <List>
              <ListItem disablePadding>
                <ListItemButton 
                  component={Link} 
                  to="fullcontent" 
                  className="list-item-button"
                  style={{ backgroundColor: 'rgb(37, 80, 123)', color: '#fff' }}
                >
                  <ListItemIcon className="list-item-icon" style={{ color: '#fff' }}>
                    <LinkIcon />
                  </ListItemIcon>
                  <ListItemText primary="Links" className="list-item-text" />
                </ListItemButton>
              </ListItem>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="fullcontent graphs" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <SpeedIcon />
                  </ListItemIcon>
                  <ListItemText primary="Graphs" className="list-item-text" />
                </ListItemButton>
              </ListItem>
            </List>
          </AccordionDetails>
        </Accordion>







<Accordion 
          expanded={expanded === 'internalLinks'} 
          onChange={handleChange('internalLinks')}
          className="accordion"
          style={{ backgroundColor: 'rgb(37, 80, 123)' }}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon sx={{ color: 'white' }} />}
            aria-controls="internalLinks-content"
            id="internalLinks-header"
            className="accordion-summary"
          >
            <ListItemIcon className="accordion-icon" style={{ color: '#fff' }}>
              <DescriptionIcon />
            </ListItemIcon>
            <ListItemText className="usha" primary="Internal Links" />
          </AccordionSummary>
          <AccordionDetails className="accordion-details">
            <List>
              <ListItem disablePadding>
                <ListItemButton 
                  component={Link} 
                  to="internallinks" 
                  className="list-item-button"
                  style={{ backgroundColor: 'rgb(37, 80, 123)', color: '#fff' }}
                >
                  <ListItemIcon className="list-item-icon" style={{ color: '#fff' }}>
                    <LinkIcon />
                  </ListItemIcon>
                  <ListItemText primary="Links" className="list-item-text" />
                </ListItemButton>
              </ListItem>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="internalgraphs" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <SpeedIcon />
                  </ListItemIcon>
                  <ListItemText primary="Graphs" className="list-item-text" />
                </ListItemButton>
              </ListItem>
            </List>
          </AccordionDetails>
        </Accordion>

        {/* Canonical Links Accordion */}
        <Accordion 
          expanded={expanded === 'canonicallinks'} 
          onChange={handleChange('canonicallinks')}
          className="accordion"
          style={{ backgroundColor: 'rgb(37, 80, 123)' }}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon sx={{ color: 'white' }} />}
            aria-controls="canonicallinks-content"
            id="canonicallinks-header"
            className="accordion-summary"
          >
            <ListItemIcon className="accordion-icon" style={{ color: '#fff' }}>
              <DescriptionIcon />
            </ListItemIcon>
            <ListItemText className="accordion-summary-text" primary="Canonical Links" />
          </AccordionSummary>
          <AccordionDetails className="accordion-details">
            <List>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="canonicallinks" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <LinkIcon />
                  </ListItemIcon>
                  <ListItemText primary="Links" />
                </ListItemButton>
              </ListItem>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="canonicalgraphs" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <SpeedIcon />
                  </ListItemIcon>
                  <ListItemText primary="Graphs" />
                </ListItemButton>
              </ListItem>
            </List>
          </AccordionDetails>
        </Accordion>









        {/* Backlink Analysis Accordion */}
        <Accordion 
          expanded={expanded === 'backlinkAnalysis'} 
          onChange={handleChange('backlinkAnalysis')}
          className="accordion"
          style={{ backgroundColor: 'rgb(37, 80, 123)' }}  // Correct way to set background color

        >
          <AccordionSummary
    expandIcon={<ExpandMoreIcon sx={{ color: 'white' }} />}  // Apply styles directly here
    aria-controls="backlinkAnalysis-content"
            id="backlinkAnalysis-header"
            className="accordion-summary"
          >
            <ListItemIcon className="accordion-icon"  style={{color:'#fff'}}>
              <DescriptionIcon />
            </ListItemIcon>
            <ListItemText className="accordion-summary-text" primary="Backlink Analysis" />
          </AccordionSummary>
          <AccordionDetails className="accordion-details">
            <List>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="backlinks" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <LinkIcon />
                  </ListItemIcon>
                  <ListItemText primary="Links" />
                </ListItemButton>
              </ListItem>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="/backgraphs" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <SpeedIcon />
                  </ListItemIcon>
                  <ListItemText primary="Graphs" />
                </ListItemButton>
              </ListItem>
            </List>
          </AccordionDetails>
        </Accordion>

        {/* Add more sections as needed */}
      {/* Crawed Links Accordion */}
      <Accordion 
          expanded={expanded === 'crawedLinks'} 
          onChange={handleChange('crawedLinks')}
          className="accordion"
          style={{ backgroundColor: 'rgb(37, 80, 123)', color: '#fff' }} 
        >
          <AccordionSummary
    expandIcon={<ExpandMoreIcon sx={{ color: 'white' }} />}  // Apply styles directly here
    aria-controls="crawedLinks-content"
            id="crawedLinks-header"
            className="accordion-summary"
          >
            <ListItemIcon className="accordion-icon"  style={{color:'#fff'}}>
              <DescriptionIcon />
            </ListItemIcon>
            <ListItemText className="accordion-summary-text" primary="Crawed Links" />
          </AccordionSummary>
          <AccordionDetails className="accordion-details">
            <List>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="/crawedlinks" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <LinkIcon />
                  </ListItemIcon>
                  <ListItemText primary="Links" />
                </ListItemButton>
              </ListItem>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="/crawedgraphs" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <SpeedIcon />
                  </ListItemIcon>
                  <ListItemText primary="Graphs" />
                </ListItemButton>
              </ListItem>
            </List>
          </AccordionDetails>
        </Accordion>

        {/* Canonical Links Accordion */}

        <Accordion 
          expanded={expanded === 'externalLinks'} 
          onChange={handleChange('externalLinks')}
          className="accordion"
          style={{ backgroundColor: 'rgb(37, 80, 123)' }}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon sx={{ color: 'white' }} />}
            aria-controls="externalLinks-content"
            id="externalLinks-header"
            className="accordion-summary"
          >
            <ListItemIcon className="accordion-icon" style={{ color: '#fff' }}>
              <DescriptionIcon />
            </ListItemIcon>
            <ListItemText className="accordion-summary-text" primary="External Links" />
          </AccordionSummary>
          <AccordionDetails className="accordion-details">
            <List>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="externallinks" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <LinkIcon />
                  </ListItemIcon>
                  <ListItemText primary="Links" />
                </ListItemButton>
              </ListItem>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="externalgraphs" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <SpeedIcon />
                  </ListItemIcon>
                  <ListItemText primary="Graphs" />
                </ListItemButton>
              </ListItem>
            </List>
          </AccordionDetails>
        </Accordion>


        {/* Do Follow Accordion */}
        <Accordion 
          expanded={expanded === 'doFollow'} 
          onChange={handleChange('doFollow')}
          className="accordion"
          style={{ backgroundColor: 'rgb(37, 80, 123)', color: '#fff' }} 
        >
          <AccordionSummary
    expandIcon={<ExpandMoreIcon sx={{ color: 'white' }} />}  // Apply styles directly here
    aria-controls="doFollow-content"
            id="doFollow-header"
            className="accordion-summary"
          >
            <ListItemIcon className="accordion-icon"  style={{color:'#fff'}}>
              <DescriptionIcon />
            </ListItemIcon>
            <ListItemText className="accordion-summary-text" primary="Do Follow" />
          </AccordionSummary>
          <AccordionDetails className="accordion-details">
            <List>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="dofollow" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <LinkIcon />
                  </ListItemIcon>
                  <ListItemText primary="Links" />
                </ListItemButton>
              </ListItem>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="/dofollowgraphs" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <SpeedIcon />
                  </ListItemIcon>
                  <ListItemText primary="Graphs" />
                </ListItemButton>
              </ListItem>
            </List>
          </AccordionDetails>
        </Accordion>
    {/* Indexibility Accordion */}
    <Accordion 
          expanded={expanded === 'indexibility'} 
          onChange={handleChange('indexibility')}
          className="accordion"
          style={{ backgroundColor: 'rgb(37, 80, 123)', color: '#fff' }} 
        >
          <AccordionSummary
    expandIcon={<ExpandMoreIcon sx={{ color: 'white' }} />}  // Apply styles directly here
    aria-controls="indexibility-content"
            id="indexibility-header"
            className="accordion-summary"
          >
            <ListItemIcon className="accordion-icon" style={{color:'#fff'}}>
              <DescriptionIcon />
            </ListItemIcon>
            <ListItemText className="accordion-summary-text" primary="Indexibility" />
          </AccordionSummary>
          <AccordionDetails className="accordion-details">
            <List>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="indexibility" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <LinkIcon />
                  </ListItemIcon>
                  <ListItemText primary="Links" />
                </ListItemButton>
              </ListItem>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="/indexibilitygraphs" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <SpeedIcon />
                  </ListItemIcon>
                  <ListItemText primary="Graphs" />
                </ListItemButton>
              </ListItem>
            </List>
          </AccordionDetails>
        </Accordion>

        {/* Sitemaps Accordion */}
        <Accordion 
          expanded={expanded === 'sitemaps'} 
          onChange={handleChange('sitemaps')}
          className="accordion"
          style={{ backgroundColor: 'rgb(37, 80, 123)', color: '#fff' }} 
        >
          <AccordionSummary
    expandIcon={<ExpandMoreIcon sx={{ color: 'white' }} />}  // Apply styles directly here
    aria-controls="sitemaps-content"
            id="sitemaps-header"
            className="accordion-summary"
          >
            <ListItemIcon className="accordion-icon"  style={{color:'#fff'}}>
              <DescriptionIcon />
            </ListItemIcon>
            <ListItemText className="accordion-summary-text" primary="Sitemaps" />
          </AccordionSummary>
          <AccordionDetails className="accordion-details">
            <List>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="sitemap" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <LinkIcon />
                  </ListItemIcon>
                  <ListItemText primary="Links" />
                </ListItemButton>
              </ListItem>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="/sitemapgraphs" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <SpeedIcon />
                  </ListItemIcon>
                  <ListItemText primary="Graphs" />
                </ListItemButton>
              </ListItem>
            </List>
          </AccordionDetails>
        </Accordion>

        {/* Social Tags Accordion */}
        <Accordion 
          expanded={expanded === 'socialTags'} 
          onChange={handleChange('socialTags')}
          className="accordion"
          style={{ backgroundColor: 'rgb(37, 80, 123)', color: '#fff' }} 
        >
          <AccordionSummary
    expandIcon={<ExpandMoreIcon sx={{ color: 'white' }} />}  // Apply styles directly here
    aria-controls="socialTags-content"
            id="socialTags-header"
            className="accordion-summary"
          >
            <ListItemIcon className="accordion-icon"  style={{color:'#fff'}}>
              <DescriptionIcon />
            </ListItemIcon>
            <ListItemText className="accordion-summary-text" primary="Social Tags" />
          </AccordionSummary>
          <AccordionDetails className="accordion-details">
            <List>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="socialtags" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <LinkIcon />
                  </ListItemIcon>
                  <ListItemText primary="Links" />
                </ListItemButton>
              </ListItem>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="/socialtagsgraphs" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <SpeedIcon />
                  </ListItemIcon>
                  <ListItemText primary="Graphs" />
                </ListItemButton>
              </ListItem>
            </List>
          </AccordionDetails>
        </Accordion>
        <Accordion 
          expanded={expanded === 'headings'} 
          onChange={handleChange('headings')}
          className="accordion"
          style={{ backgroundColor: 'rgb(37, 80, 123)', color: '#fff' }} 
        >
          <AccordionSummary
    expandIcon={<ExpandMoreIcon sx={{ color: 'white' }} />}  // Apply styles directly here
    aria-controls="headings-content"
            id="headings-header"
            className="accordion-summary"
          >
            <ListItemIcon className="accordion-icon"  style={{color:'#fff'}}>
              <DescriptionIcon />
            </ListItemIcon>
            <ListItemText className="accordion-summary-text" primary="Headings" />
          </AccordionSummary>
          <AccordionDetails className="accordion-details">
            <List>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="headings" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <LinkIcon />
                  </ListItemIcon>
                  <ListItemText primary="Links" />
                </ListItemButton>
              </ListItem>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="/headingsgraphs" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <SpeedIcon />
                  </ListItemIcon>
                  <ListItemText primary="Graphs" />
                </ListItemButton>
              </ListItem>
            </List>
          </AccordionDetails>
        </Accordion>

        {/* Errors Accordion */}
        <Accordion 
          expanded={expanded === 'errors'} 
          onChange={handleChange('errors')}
          className="accordion"
          style={{ backgroundColor: 'rgb(37, 80, 123)', color: '#fff' }} 
        >
          <AccordionSummary
    expandIcon={<ExpandMoreIcon sx={{ color: 'white' }} />}  // Apply styles directly here
    aria-controls="errors-content"
            id="errors-header"
            className="accordion-summary"
          >
            <ListItemIcon className="accordion-icon"  style={{color:'#fff'}}>
              <DescriptionIcon />
            </ListItemIcon>
            <ListItemText className="accordion-summary-text" primary="Errors" />
          </AccordionSummary>
          <AccordionDetails className="accordion-details">
            <List>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="errors" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <LinkIcon />
                  </ListItemIcon>
                  <ListItemText primary="Links" />
                </ListItemButton>
              </ListItem>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="/errorsgraphs" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <SpeedIcon />
                  </ListItemIcon>
                  <ListItemText primary="Graphs" />
                </ListItemButton>
              </ListItem>
            </List>
          </AccordionDetails>
        </Accordion>

        {/* URL Analyzer Accordion */}
        <Accordion 
          expanded={expanded === 'urlAnalyzer'} 
          onChange={handleChange('urlAnalyzer')}
          className="accordion"
          style={{ backgroundColor: 'rgb(37, 80, 123)', color: '#fff' }} 
        >
          <AccordionSummary
    expandIcon={<ExpandMoreIcon sx={{ color: 'white' }} />}  // Apply styles directly here
    aria-controls="urlAnalyzer-content"
            id="urlAnalyzer-header"
            className="accordion-summary"
          >
            <ListItemIcon className="accordion-icon" style={{color:'#fff'}}>
              <DescriptionIcon />
            </ListItemIcon>
            <ListItemText className="accordion-summary-text" primary="URL Analyzer" />
          </AccordionSummary>
          <AccordionDetails className="accordion-details">
            <List>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="urlanalyzer" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <LinkIcon />
                  </ListItemIcon>
                  <ListItemText primary="Links" />
                </ListItemButton>
              </ListItem>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="/urlanalyzergraphs" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <SpeedIcon />
                  </ListItemIcon>
                  <ListItemText primary="Graphs" />
                </ListItemButton>
              </ListItem>
            </List>
          </AccordionDetails>
        </Accordion>

        {/* Website Analyzer Accordion */}
        <Accordion 
          expanded={expanded === 'websiteAnalyzer'} 
          onChange={handleChange('websiteAnalyzer')}
          className="accordion"
          style={{ backgroundColor: 'rgb(37, 80, 123)', color: '#fff' }} 
        >
          <AccordionSummary
    expandIcon={<ExpandMoreIcon sx={{ color: 'white' }} />}  // Apply styles directly here
    aria-controls="websiteAnalyzer-content"
            id="websiteAnalyzer-header"
            className="accordion-summary"
          >
            <ListItemIcon className="accordion-icon"  style={{color:'#fff'}}>
              <DescriptionIcon />
            </ListItemIcon>
            <ListItemText className="accordion-summary-text" primary="Website Analyzer" />
          </AccordionSummary>
          <AccordionDetails className="accordion-details">
            <List>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="websiteanalyzer" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <LinkIcon />
                  </ListItemIcon>
                  <ListItemText primary="Links" />
                </ListItemButton>
              </ListItem>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="/websiteanalyzergraphs" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <SpeedIcon />
                  </ListItemIcon>
                  <ListItemText primary="Graphs" />
                </ListItemButton>
              </ListItem>
            </List>
          </AccordionDetails>
        </Accordion>

        {/* Status 200 Links Accordion */}
        <Accordion 
          expanded={expanded === 'status200Links'} 
          onChange={handleChange('status200Links')}
          className="accordion"
          style={{ backgroundColor: 'rgb(37, 80, 123)', color: '#fff' }} 
        >
          <AccordionSummary
    expandIcon={<ExpandMoreIcon sx={{ color: 'white' }} />}  // Apply styles directly here
    aria-controls="status200Links-content"
            id="status200Links-header"
            className="accordion-summary"
          >
            <ListItemIcon className="accordion-icon"  style={{color:'#fff'}}>
              <DescriptionIcon />
            </ListItemIcon>
            <ListItemText className="accordion-summary-text" primary="Status 200 Links" />
          </AccordionSummary>
          <AccordionDetails className="accordion-details">
            <List>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="status200links" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <LinkIcon />
                  </ListItemIcon>
                  <ListItemText primary="Links" />
                </ListItemButton>
              </ListItem>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="/status200linksgraphs" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <SpeedIcon />
                  </ListItemIcon>
                  <ListItemText primary="Graphs" />
                </ListItemButton>
              </ListItem>
            </List>
          </AccordionDetails>
        </Accordion>

        
        <Accordion 
          expanded={expanded === 'keywordResearch'} 
          onChange={handleChange('keywordResearch')}
          className="accordion"
          style={{ backgroundColor: 'rgb(37, 80, 123)', color: '#fff' }} 
        >
          <AccordionSummary
    expandIcon={<ExpandMoreIcon sx={{ color: 'white' }} />}  // Apply styles directly here
    aria-controls="keywordResearch-content"
            id="keywordResearch-header"
            className="accordion-summary"
          >
            <ListItemIcon className="accordion-icon"  style={{color:'#fff'}}>
              <DescriptionIcon />
            </ListItemIcon>
            <ListItemText className="accordion-summary-text" primary="Keyword Research" />
          </AccordionSummary>
          <AccordionDetails className="accordion-details">
            <List>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="keywordresearch" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <LinkIcon />
                  </ListItemIcon>
                  <ListItemText primary="Links" />
                </ListItemButton>
              </ListItem>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="/keywordresearchgraphs" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <SpeedIcon />
                  </ListItemIcon>
                  <ListItemText primary="Graphs" />
                </ListItemButton>
              </ListItem>
            </List>
          </AccordionDetails>
        </Accordion>

        {/* Keyword Suggestion Accordion */}
        <Accordion 
          expanded={expanded === 'keywordSuggestion'} 
          onChange={handleChange('keywordSuggestion')}
          className="accordion"
          style={{ backgroundColor: 'rgb(37, 80, 123)', color: '#fff' }} 
        >
          <AccordionSummary
    expandIcon={<ExpandMoreIcon sx={{ color: 'white' }} />}  // Apply styles directly here
    aria-controls="keywordSuggestion-content"
            id="keywordSuggestion-header"
            className="accordion-summary"
          >
            <ListItemIcon className="accordion-icon"  style={{color:'#fff'}}>
              <DescriptionIcon />
            </ListItemIcon>
            <ListItemText className="accordion-summary-text" primary="Keyword Suggestion" />
          </AccordionSummary>
          <AccordionDetails className="accordion-details">
            <List>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="keywordsuggestion" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <LinkIcon />
                  </ListItemIcon>
                  <ListItemText primary="Links" />
                </ListItemButton>
              </ListItem>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="/keywordsuggestiongraphs" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <SpeedIcon />
                  </ListItemIcon>
                  <ListItemText primary="Graphs" />
                </ListItemButton>
              </ListItem>
            </List>
          </AccordionDetails>
        </Accordion>

        {/* Image Links Accordion */}
        <Accordion 
          expanded={expanded === 'imageLinks'} 
          onChange={handleChange('imageLinks')}
          className="accordion"
          style={{ backgroundColor: 'rgb(37, 80, 123)', color: '#fff' }} 
        >
          <AccordionSummary
    expandIcon={<ExpandMoreIcon sx={{ color: 'white' }} />}  // Apply styles directly here
    aria-controls="imageLinks-content"
            id="imageLinks-header"
            className="accordion-summary"
          >
            <ListItemIcon className="accordion-icon"  style={{color:'#fff'}}>
              <ImageIcon />
            </ListItemIcon>
            <ListItemText className="accordion-summary-text" primary="Image Links" />
          </AccordionSummary>
          <AccordionDetails className="accordion-details">
            <List>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="imagelinks" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <LinkIcon />
                  </ListItemIcon>
                  <ListItemText primary="Links" />
                </ListItemButton>
              </ListItem>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="/imagelinksgraphs" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <SpeedIcon />
                  </ListItemIcon>
                  <ListItemText primary="Graphs" />
                </ListItemButton>
              </ListItem>
            </List>
          </AccordionDetails>
        </Accordion>

        {/* Image Resources Accordion */}
        <Accordion 
          expanded={expanded === 'imageResources'} 
          onChange={handleChange('imageResources')}
          className="accordion"
          style={{ backgroundColor: 'rgb(37, 80, 123)', color: '#fff' }} 
        >
          <AccordionSummary
    expandIcon={<ExpandMoreIcon sx={{ color: 'white' }} />}  // Apply styles directly here
    aria-controls="imageResources-content"
            id="imageResources-header"
            className="accordion-summary"
          >
            <ListItemIcon className="accordion-icon"  style={{color:'#fff'}}>
              <ImageIcon />
            </ListItemIcon>
            <ListItemText className="accordion-summary-text" primary="Image Resources" />
          </AccordionSummary>
          <AccordionDetails className="accordion-details">
            <List>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="imageresources" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <LinkIcon />
                  </ListItemIcon>
                  <ListItemText primary="Links" />
                </ListItemButton>
              </ListItem>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="/imageresourcesgraphs" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <SpeedIcon />
                  </ListItemIcon>
                  <ListItemText primary="Graphs" />
                </ListItemButton>
              </ListItem>
            </List>
          </AccordionDetails>
        </Accordion>

      

        {/* Title Accordion */}
        <Accordion 
          expanded={expanded === 'title'} 
          onChange={handleChange('title')}
          className="accordion"
          style={{ backgroundColor: 'rgb(37, 80, 123)', color: '#fff' }} 
        >
          <AccordionSummary
    expandIcon={<ExpandMoreIcon sx={{ color: 'white' }} />}  // Apply styles directly here
    aria-controls="title-content"
            id="title-header"
            className="accordion-summary"
          >
            <ListItemIcon className="accordion-icon"  style={{color:'#fff'}}>
              <TitleIcon />
            </ListItemIcon>
            <ListItemText className="accordion-summary-text" primary="Title" />
          </AccordionSummary>
          <AccordionDetails className="accordion-details">
            <List>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="title" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <LinkIcon />
                  </ListItemIcon>
                  <ListItemText primary="Links" />
                </ListItemButton>
              </ListItem>
              <ListItem disablePadding>
                <ListItemButton component={Link} to="/titlegraphs" className="list-item-button">
                  <ListItemIcon className="list-item-icon">
                    <SpeedIcon />
                  </ListItemIcon>
                  <ListItemText primary="Graphs" />
                </ListItemButton>
              </ListItem>
            </List>
          </AccordionDetails>
        </Accordion>
      </List>
      </Drawer>
      <Main open={open}>
        <DrawerHeader />
        <Routes>
        <Route path="/" element={<DefaultDashboardContent />} />


          <Route path="/internallinks" element={<Internallinks />} />
          <Route path="/keywordResearch" element={<KeywordResearch />} />
          <Route path="/fullcontent" element={<FullContent />} />
          <Route path="/sitemap" element={<Sitemap />} />
          <Route path="/urlanalyser" element={<Urlanalyser />} />
          <Route path="/indexibility" element={<Indexibility />} />
          <Route path="/status200links" element={<Status200Links />} />
          <Route path="/socialtags" element={<Socialtags />} />
          <Route path="/directives" element={<Directives />} />
          <Route path="/imageresources" element={<Imageresource />} />
          <Route path="/keywordsuggestion" element={<KeywordSuggestion />} />
          <Route path="/wesiteanalyslinks" element={<WesiteAnalysLinks />} />
          <Route path="/canonicallinks" element={<Canonicallinks />} />
          <Route path="/brokenimages" element={<Brokenimages />} />
          <Route path="/title" element={<Title />} />
          <Route path="/errorlinks" element={<Errorlinks />} />
          <Route path="/headings" element={<Headings />} />
          <Route path="/dofollow" element={<DoFollow />} />
          <Route path="/crawedlinks" element={<Crawedlinks />} />
          <Route path="/imagelinks" element={<Imagelinks />} />
          <Route path="/addkeyword" element={<AddKeyword />} />
          <Route path="/analyzePage" element={<AnalyzePage />} />
          <Route path="/externallinks" element={<Externallinks />} />
          <Route path="/backlinks" element={<Backlinks />} />


        </Routes>
      </Main>
    </Box>
  );
}
