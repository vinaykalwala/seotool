import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import '../Css/File.css';
import { Pie, Bar, Line } from 'react-chartjs-2';
import 'chart.js/auto';
import CircularProgress from '@material-ui/core/CircularProgress';
import { makeStyles } from '@material-ui/core/styles';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { Button, Card, CardContent, CardHeader, Grid } from '@mui/material';
import { Link } from 'react-router-dom';
import { Typography } from '@mui/material';
import { Container, List, ListItem, ListItemText } from '@mui/material';
import Dropdown from 'react-bootstrap/Dropdown';
import DropdownButton from 'react-bootstrap/DropdownButton';
import { MDBAccordion, MDBAccordionItem } from 'mdb-react-ui-kit';
import Charts from './Charts'; // Adjust the import path as needed

import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend } from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend);

const useStyles = makeStyles((theme) => ({
  spinner: {
    color: '#36A2EB',
    marginTop: theme.spacing(2),
  },
}));

const InternalLinkCounter = () => {
  const classes = useStyles();

  const [url, setUrl] = useState('');
  const [internalLinksCount, setInternalLinksCount] = useState(null);
  const [externalLinksCount, setExternalLinksCount] = useState(null);
  const [canonicalLinksCount, setcanonicalLinksCount] = useState(null);
  const [totalIndexedUrls, setTotalIndexedUrls] = useState(0);
  const [totalNonIndexedUrls, setTotalNonIndexedUrls] = useState(0);
  
  
  const [metaTagsCount, setMetaTagsCount] = useState(null);
  const [backlinksCount, setBacklinksCount] = useState(null);
  const [internalLinks, setInternalLinks] = useState([]);
  const [externalLinks, setExternalLinks] = useState([]);
  const [totalCrawledLinks, setTotalCrawledLinks] = useState(null);
  const [htmlPagesCount, setHtmlPagesCount] = useState(null);
  const [nonHtmlFilesCount, setNonHtmlFilesCount] = useState(null);
  const [redirects, setRedirects] = useState([]);
  const [brokenLinks, setBrokenLinks] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [showLinks, setShowLinks] = useState(null);
  const [dofollowInternalLinks, setDofollowInternalLinks] = useState([]);
  const [nofollowInternalLinks, setNofollowInternalLinks] = useState([]);
  const [canonicalLinks, setCanonicalLinks] = useState([]);
  const [nonCanonicalLinks, setNonCanonicalLinks] = useState([]);
  const [httpLinksCount, setHttpLinksCount] = useState(0);
  const [httpsLinksCount, setHttpsLinksCount] = useState(0);
  const [totalImages, setTotalImages] = useState(0);
  const canonicalChartRef = useRef(null);
  const brokenLinksChartRef = useRef(null);
  const htmlPagesChartRef = useRef(null);
  const redirectsChartRef = useRef(null);
  const protocolChartRef = useRef(null);
  const lineChartRef = useRef(null);
  const barChartRef = useRef(null);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [timerRunning, setTimerRunning] = useState(true);
  const timerRef = useRef(null);
  const [crawledLinks, setCrawledLinks] = useState([]);
  const [metaTags, setMetaTags] = useState([]);
  const [websiteLink, setWebsiteLink] = useState('');
  const [titles, setTitles] = useState([]);
  const [totalImageCount, setTotalImageCount] = useState(0);
  const [totalUncrawledLinks, setTotalUncrawledLinks] = useState(0);



  const handleButtonClick6= () => {
    localStorage.setItem('htmlPages', JSON.stringify({
      count: htmlPagesCount,
      links: internalLinks // Assuming you want to pass internal links or related data
    }));
  };
  
  const handleButtonClick = () => {
    localStorage.setItem('internallinks', JSON.stringify(internalLinks));
  };
  const handleButtonClick5= () => {
    localStorage.setItem('nonHtmlFiles', JSON.stringify({
      count: nonHtmlFilesCount,
      links: internalLinks // Assuming you want to pass internal links or related data
    }));
  };
  

  const handleButtonClick1 = () => {
    localStorage.setItem('externallinks', JSON.stringify(externalLinks));
  };


  const handleButtonClick2 = () => {
    localStorage.setItem('metaTags', JSON.stringify({
      count: metaTagsCount,
      tags: metaTags // Replace this with the relevant data if needed
    }));
  };
  
  
  const handleButtonClick3 = () => {
    console.log('crawledLinks:', crawledLinks); // Log before saving
    localStorage.setItem('crawledLinks', JSON.stringify(crawledLinks));
  };
  
  const handleButtonClick4= () => {
    localStorage.setItem('totalHtmlPages', JSON.stringify({
      count: htmlPagesCount,
      links: internalLinks // Assuming you want to pass internal links
    }));
  };
  

  const handleButtonClick7= () => {
    localStorage.setItem('backlinks', JSON.stringify({
      count: backlinksCount,
      links: internalLinks // Replace this with the relevant data if needed
    }));
  };
  const handleButtonClick8 = () => {
    localStorage.setItem('brokenLinks', JSON.stringify({
      count: brokenLinks.length,
      links: brokenLinks
    }));
  };
  
  useEffect(() => {
    const storedData = localStorage.getItem('dashboardData');
    if (storedData) {
      const data = JSON.parse(storedData);
      setInternalLinksCount(data.internalLinksCount);
      setExternalLinksCount(data.externalLinksCount);
      setcanonicalLinksCount(data.canonicalLinksCount);
      setMetaTagsCount(data.metaTagsCount);
      setBacklinksCount(data.backlinksCount);
      setInternalLinks(data.internalLinks);
      setExternalLinks(data.externalLinks);
      setTotalCrawledLinks(data.totalCrawledLinks);
      setHtmlPagesCount(data.htmlPagesCount);
      setNonHtmlFilesCount(data.nonHtmlFilesCount);
      setRedirects(data.redirects);
      setBrokenLinks(data.brokenLinks);
      setDofollowInternalLinks(data.dofollowInternalLinks);
      setNofollowInternalLinks(data.nofollowInternalLinks);
      setCanonicalLinks(data.canonicalLinks);
      setNonCanonicalLinks(data.nonCanonicalLinks);
      setTotalImages(data.totalImages);
      setHttpLinksCount(data.httpLinksCount);
      setHttpsLinksCount(data.httpsLinksCount);
    }
  }, []);
  useEffect(() => {
    const storedMetaTags = localStorage.getItem('metaTagsCount');
    console.log('Retrieved metaTags:', storedMetaTags);
    if (storedMetaTags) {
      setMetaTagsCount(JSON.parse(storedMetaTags));
    }
  }, []);
  
  useEffect(() => {
    if (!url) return;

    setLoading(true);

    axios.get(`http://localhost:8000/overview/?url=${encodeURIComponent(url)}`)
      .then(response => {
        const {
          internal_links_count,
          external_links_count,
          meta_tags_count,
          backlinks_count,
          internal_links,
          external_links,
          total_crawled_links,
          html_pages_count,
          non_html_files_count,
          redirects,
          broken_links,
          dofollow_internal_links,
          nofollow_internal_links,
          canonical_links,
          non_canonical_links,
          total_indexed_urls,
          total_non_indexed_urls,
          total_images,
          total_uncrawled_links
        } = response.data;

        const httpLinks = internal_links.filter(link => link.startsWith('http://')).length +
                          external_links.filter(link => link.startsWith('http://')).length;
        const httpsLinks = internal_links.filter(link => link.startsWith('https://')).length +
                           external_links.filter(link => link.startsWith('https://')).length;

        setInternalLinksCount(internal_links_count);
        setExternalLinksCount(external_links_count);
        setExternalLinksCount(external_links_count);
        setTotalIndexedUrls(total_indexed_urls);
        setTotalNonIndexedUrls(total_non_indexed_urls);
        setMetaTagsCount(meta_tags_count);
        setBacklinksCount(backlinks_count);
        setInternalLinks(internal_links);
        setExternalLinks(external_links);
        setTotalCrawledLinks(total_crawled_links);
        setHtmlPagesCount(html_pages_count);
        setNonHtmlFilesCount(non_html_files_count);
        setRedirects(redirects);
        setBrokenLinks(broken_links);
        setDofollowInternalLinks(dofollow_internal_links);
        setNofollowInternalLinks(nofollow_internal_links);
        setCanonicalLinks(canonical_links);
        setNonCanonicalLinks(non_canonical_links);
        setTotalImages(total_images);
        setHttpLinksCount(httpLinks);
        setHttpsLinksCount(httpsLinks);
        setTotalUncrawledLinks(total_uncrawled_links);
setTotalIndexedUrls(total_indexed_urls);
setTotalNonIndexedUrls(total_non_indexed_urls);

        localStorage.setItem('dashboardData', JSON.stringify({
          internalLinksCount: internal_links_count,
          externalLinksCount: external_links_count,
          metaTagsCount: meta_tags_count,
          backlinksCount: backlinks_count,
          internalLinks,
          externalLinks,
          totalCrawledLinks: total_crawled_links,
          htmlPagesCount: html_pages_count,
          nonHtmlFilesCount: non_html_files_count,
          redirects,
          brokenLinks: broken_links,
          dofollowInternalLinks: dofollow_internal_links,
          nofollowInternalLinks: nofollow_internal_links,
          canonicalLinks: canonical_links,
          nonCanonicalLinks: non_canonical_links,
          totalImages: total_images,
          httpLinksCount: httpLinks,
          httpsLinksCount: httpsLinks,
        }));

        setError(null);
      })
      .catch(error => {
        setError(error.response ? error.response.data.error : 'fttching error');
      })
      .finally(() => {
        setLoading(false);
      });
  }, [url]);
  const handleSearch = () => {
    setInternalLinksCount(null);
    setExternalLinksCount(null);
    setMetaTagsCount(null);
    setBacklinksCount(null);
    setError(null);
    setInternalLinks([]);
    setExternalLinks([]);
    setTotalCrawledLinks(null);
    setHtmlPagesCount(null);
    setNonHtmlFilesCount(null);
    setRedirects([]);
    setBrokenLinks([]);
    setHttpLinksCount(0);
    setHttpsLinksCount(0);
    setDofollowInternalLinks([]);
    setNofollowInternalLinks([]);
    setTotalImages(0);
    setUrl(document.getElementById('urlInput').value);
  };

  useEffect(() => {
    const options = {
      responsive: true,
      plugins: {
        legend: {
          position: 'top',
        },
        title: {
          display: true,
          text: 'Counts of Various Metrics',
        },
      },
    };

    return () => {
      if (brokenLinksChartRef.current && brokenLinksChartRef.current.chartInstance) {
        brokenLinksChartRef.current.chartInstance.destroy();
      }
      if (htmlPagesChartRef.current && htmlPagesChartRef.current.chartInstance) {
        htmlPagesChartRef.current.chartInstance.destroy();
      }
      if (redirectsChartRef.current && redirectsChartRef.current.chartInstance) {
        redirectsChartRef.current.chartInstance.destroy();
      }
      if (protocolChartRef.current && protocolChartRef.current.chartInstance) {
        protocolChartRef.current.chartInstance.destroy();
      }
      if (canonicalChartRef.current && canonicalChartRef.current.chartInstance) {
        canonicalChartRef.current.chartInstance.destroy();
      }
      if (barChartRef.current && barChartRef.current.chartInstance) {
        barChartRef.current.chartInstance.destroy();
      }
    };
  }, [brokenLinks, htmlPagesCount, nonHtmlFilesCount, redirects, httpLinksCount, httpsLinksCount]);

  const brokenLinksData = {
    labels: ['Broken Links', 'Non-Broken Links'],
    datasets: [
      {
        data: [brokenLinks.length || 0, (internalLinks.length + externalLinks.length - brokenLinks.length) || 0],
        backgroundColor: ['#FF6347', '#36A2EB'],
      },
    ],
  };

  const htmlPagesData = {
    labels: ['HTML Pages', 'Non-HTML Files'],
    datasets: [
      {
        data: [htmlPagesCount, nonHtmlFilesCount],
        backgroundColor: ['#FFD700', '#ADFF2F'],
      },
    ],
  };

  const redirectsData = {
    labels: ['Redirect Links', 'Non-Redirect Links'],
    datasets: [
      {
        data: [redirects.length, internalLinks.length + externalLinks.length - redirects.length],
        backgroundColor: ['#FFA500', '#9932CC'],
      },
    ],
  };

  const protocolData = {
    labels: ['HTTP Links', 'HTTPS Links'],
    datasets: [
      {
        data: [httpLinksCount, httpsLinksCount],
        backgroundColor: ['#DC143C', '#00FA9A'],
      },
    ],
  };

  const canonicalData = {
    labels: ['Canonical Links', 'Non-Canonical Links'],
    datasets: [
      {
        data: [canonicalLinks.length, nonCanonicalLinks.length],
        backgroundColor: ['#0000FF', '#008080'],
      },
    ],
  };

  const barData = {
    labels: [
      'Internal Links',
      'External Links',
      'Meta Tags',
      'Backlinks',
      'Total Crawled Links',
      'HTML Pages',
      'Non-HTML Files',
      'Total Images'
    ],
    datasets: [
      {
        label: 'Counts',
        data: [
          internalLinksCount,
          externalLinksCount,
          metaTagsCount,
          backlinksCount,
          totalCrawledLinks,
          htmlPagesCount,
          nonHtmlFilesCount,
          totalImages
        ],
        backgroundColor: [
          '#36A2EB',
          '#FF6384',
          '#4BC0C0',
          '#FFCE56',
          '#8A2BE2',
          '#D2691E',
          '#DC143C',
          '#00FA9A'
        ],
      },
    ],
  };
  

  const lineData = {
    labels: [
      'Internal Links',
      'External Links',
      'Meta Tags',
      'Backlinks',
      'Total Crawled Links',
      'HTML Pages',
      'Non-HTML Files',
      'Total Images'
    ],
    datasets: [
      {
        label: 'Counts',
        data: [
          internalLinksCount,
          externalLinksCount,
          metaTagsCount,
          backlinksCount,
          totalCrawledLinks,
          htmlPagesCount,
          nonHtmlFilesCount,
          totalImages
        ],
        fill: false,
        borderColor: '#36A2EB',
      },
    ],
  };
  

  const handleDownloadPDF = () => {
    const elementsToCapture = [
      { ref: brokenLinksChartRef, id: 'brokenLinksChart' },
      { ref: htmlPagesChartRef, id: 'htmlPagesChart' },
      { ref: redirectsChartRef, id: 'redirectsChart' },
      { ref: protocolChartRef, id: 'protocolChart' },
      { ref: canonicalChartRef, id: 'canonicalChart' },
      { ref: lineChartRef, id: 'lineChart' },
      { ref: barChartRef, id: 'barChart' }
    ];

    const capturedElements = [];

    const captureNextElement = (index) => {
      if (index >= elementsToCapture.length) {
        const doc = new jsPDF();

        // Add website link
        doc.setFontSize(16);
        doc.text('Summary Report', 10, 10);
        doc.setFontSize(12);
        doc.text(`Website: ${websiteLink || 'N/A'}`, 10, 20);

        // Add summary information
        doc.text(`Internal Links Count: ${internalLinksCount || 'N/A'}`, 10, 30);
        doc.text(`External Links Count: ${externalLinksCount || 'N/A'}`, 10, 40);
        doc.text(`Canonical Links Count: ${canonicalLinksCount || 'N/A'}`, 10, 50);
        doc.text(`Meta Tags Count: ${metaTagsCount || 'N/A'}`, 10, 60);
        doc.text(`Backlinks Count: ${backlinksCount || 'N/A'}`, 10, 70);
        doc.text(`Total Crawled Links: ${totalCrawledLinks || 'N/A'}`, 10, 80);
        doc.text(`HTML Pages Count: ${htmlPagesCount || 'N/A'}`, 10, 90);
        doc.text(`Non-HTML Files Count: ${nonHtmlFilesCount || 'N/A'}`, 10, 100);
        doc.text(`Total Images: ${totalImages || 'N/A'}`, 10, 110);
        doc.text(`HTTP Links Count: ${httpLinksCount || 'N/A'}`, 10, 120);
        doc.text(`HTTPS Links Count: ${httpsLinksCount || 'N/A'}`, 10, 130);

        doc.addPage();

        capturedElements.forEach(({ canvas, id }, index) => {
          const imgData = canvas.toDataURL('image/png');
          const yOffset = 10 + (index * 130); // Adjust yOffset to fit multiple images
          doc.addImage(imgData, 'PNG', 10, yOffset, 180, 120);
          if (index < capturedElements.length - 1) {
            doc.addPage();
          }
        });

        doc.save('charts.pdf');
        return;
      }

      const { ref, id } = elementsToCapture[index];
      const element = ref.current;

      if (!element) {
        captureNextElement(index + 1);
        return;
      }

      html2canvas(element)
        .then((canvas) => {
          capturedElements.push({ canvas, id });
          captureNextElement(index + 1);
        })
        .catch((error) => {
          console.error(`Error capturing ${id}:`, error);
          captureNextElement(index + 1);
        });
    };

    captureNextElement(0);
  };
  
  const toggleLinks = (type) => {
    setShowLinks((prevShowLinks) => (prevShowLinks === type ? null : type));
  };




  
  return (
    <div className="App">

<DropdownButton className="dropdown-button" id="dropdown-basic-button" title="Dropdown button">
<Dropdown.Item href="#/action-1">Action</Dropdown.Item>
      <Dropdown.Item href="/admin/fullcontent/internallinks/internallinksseperate">Internal links</Dropdown.Item>
      <Dropdown.Item href="/admin/fullcontent/externallinksseperate">External links</Dropdown.Item>

      <Dropdown.Item href="sitemap">Site maps</Dropdown.Item>
      <Dropdown.Item href="indexibility">Indexibility</Dropdown.Item>
      <Dropdown.Item href="socialtags">Social tags</Dropdown.Item>
      <Dropdown.Item href="analysewebsitecolors">Website loading</Dropdown.Item>
      <Dropdown.Item href="imagelinks">Image Links</Dropdown.Item>
      <Dropdown.Item href="competitoranalysis">Competitor Analysisn</Dropdown.Item>
      <Dropdown.Item href="seoanalysis">Seo Analysis</Dropdown.Item>
      <Dropdown.Item href="analyseseotool">Analyse Seo Tool</Dropdown.Item>
      <Dropdown.Item href="checkwebsiteaccessibility">checkwebsiteaccessibility</Dropdown.Item>
    </DropdownButton>
      <Card className="card">
        <CardHeader title="Crawl your website" />
     

     
        <CardContent>
  <input type="text" id="urlInput" placeholder="Enter URL" />

  <Button onClick={handleSearch} variant="contained" color="primary" disabled={loading}>
    Fetch Data
  </Button>
</CardContent>
 </Card>

    

      {loading && <CircularProgress size={50} className={classes.spinner} />}

      {error && <div className="error">{error}</div>}

      {!loading && internalLinksCount !== null && (
        <>



 <Typography variant="h4" component="div" gutterBottom>

      </Typography><br></br><br></br>

      <div className="cards-container">



      <Card className="custom-card">
          <CardContent className="card-content">
            {/* SVG Icon representing total crawled links */}
           
            <Link to="crawedlinks" onClick={handleButtonClick3} className="link-style">
              <Button className="custom-button">
                {totalCrawledLinks} Total Crawled Links
              </Button>
            </Link>
          </CardContent>
        </Card>










        <Card className="custom-card">
          <CardContent className="card-content">
           
            <Link to="internallinks" onClick={handleButtonClick} className="link-style">
              <Button className="custom-button">
                {internalLinksCount} Internal Links
              </Button>
            </Link>
          </CardContent>
        </Card>

        <Card className="custom-card">
  <CardContent className="card-content">
    {/* SVG Icon for External Links with color */}
   
    <Link to="externallinks" onClick={handleButtonClick1} className="link-style">
      <Button className="custom-button">
        {externalLinksCount} External Links
      </Button>
    </Link>
  </CardContent>
</Card>





<Card className="custom-card">
  <CardContent className="card-content">
    {/* SVG Icon for External Links with color */}
   
    <Link to="externallinks" onClick={handleButtonClick1} className="link-style">
      <Button className="custom-button">
        {externalLinksCount} External Links
      </Button>
    </Link>
  </CardContent>
</Card>









        <Card className="custom-card">
      <CardContent className="card-content">
        {/* SVG Icon representing meta tags */}
      
        <Link to="metatags" onClick={handleButtonClick2} className="link-style">
          <Button className="custom-button">
            {metaTagsCount} Meta Tags
          </Button>
        </Link>
      </CardContent>
    </Card>

    <Card className="custom-card">
      <CardContent className="card-content">
        {/* SVG Icon for backlinks */}
      
        <Link to="backlinksauto" onClick={handleButtonClick7} className="link-style">
          <Button className="custom-button">
            {backlinksCount} Backlinks
          </Button>
        </Link>
      </CardContent>
    </Card>

    <Card className="custom-card">
      <CardContent className="card-content">
        {/* SVG Icon for HTML Pages */}
      
        <Link to="htmlpages" onClick={handleButtonClick6} className="link-style">
          <Button className="custom-button">
            {htmlPagesCount} HTML Pages
          </Button>
        </Link>
      </CardContent>
    </Card>
    <Card className="custom-card">
      <CardContent className="card-content">
        {/* SVG Icon for Non-HTML Files */}
       
        <Link to="nonhtmlfiles" onClick={handleButtonClick5} className="link-style">
          <Button className="custom-button">
            {nonHtmlFilesCount} Non-HTML Files
          </Button>
        </Link>
      </CardContent>
    </Card>

    <Card className="custom-card">
      <CardContent className="card-content">
        {/* SVG Icon for Total Images */}
       
        <Link to="totalhtmlpages" onClick={handleButtonClick4} className="link-style">
          <Button className="custom-button">
            {totalImages} Total Images
          </Button>
        </Link>
      </CardContent>
    </Card>



    <Card className="custom-card">
  <CardContent className="card-content">
    {/* SVG Icon for Canonical Links */}
  
    <Link to="canonicalauto" onClick={handleButtonClick4} className="link-style">
      <Button className="custom-button">
        {totalImages} Canonical Links
      </Button>
    </Link>
  </CardContent>
</Card>



<Card className="custom-card">
  <CardContent className="card-content">
   
    <Link to="brokenlinks" onClick={handleButtonClick8} className="link-style">
      <Button className="custom-button">
        {brokenLinks.length} Broken Links
      </Button>
    </Link>
  </CardContent>
</Card>

<Card className="custom-card">
      <CardContent className="card-content">
       
        <Link to="brokenlinks" onClick={handleButtonClick8} className="link-style">
          <Button className="custom-button">
            {brokenLinks.length} Titles
          </Button>
        </Link>
      </CardContent>
    </Card>


    <Card className={classes.card}>
        <CardContent>
          <Typography variant="h6" component="div">
            Do Follow Links
          </Typography>
          <Typography variant="h5" component="div">
            {dofollowInternalLinks.length}
          </Typography>
          <Link to="dofollow">
            <Button className={classes.button} variant="contained" color="primary">
              View Do Follow Links
            </Button>
          </Link>
        </CardContent>
      </Card>

      <Card className={classes.card}>
        <CardContent>
          <Typography variant="h6" component="div">
            Total Uncrawled Links
          </Typography>
          <Typography variant="h5" component="div">
            {totalUncrawledLinks}
          </Typography>
        </CardContent>
      </Card>


      <Card className={classes.card}>
        <CardContent>
          <Typography variant="h6" component="div">
            No Follow Links
          </Typography>
          <Typography variant="h5" component="div">
            {nofollowInternalLinks.length}
          </Typography>
          <Link to="nofollow">
            <Button className={classes.button} variant="contained" color="primary">
              View No Follow Links
            </Button>
          </Link>
        </CardContent>
      </Card>

      <Card className={classes.card}>
        <CardContent>
          <Typography variant="h6" component="div">
            Non-Canonical Links
          </Typography>
          <Typography variant="h5" component="div">
            {nonCanonicalLinks.length}
          </Typography>
          <Link to="noncanonical">
            <Button className={classes.button} variant="contained" color="primary">
              View Non-Canonical Links
            </Button>
          </Link>
        </CardContent>
      </Card>


      <Card className={classes.card}>
        <CardContent>
          <Typography variant="h6" component="div">
            Total Image Count
          </Typography>
          <Typography variant="h5" component="div">
            {totalImageCount}
          </Typography>
          <Link to="images">
            <Button className={classes.button} variant="contained" color="primary">
              View Images
            </Button>
          </Link>
        </CardContent>
      </Card>









      </div>
  


<br></br><br></br><br></br>






          <div className="chart-container">
            <Grid container spacing={2}>
              <Grid item xs={12} md={4}>
                <Card>
                  <CardContent>
                    <h3>Broken Links Chart</h3>
                    <div ref={brokenLinksChartRef}>
                      <Pie data={brokenLinksData} />
                    </div>
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} md={4}>
                <Card>
                  <CardContent>
                    <h3>HTML Pages Chart</h3>
                    <div ref={htmlPagesChartRef}>
                      <Pie data={htmlPagesData} />
                    </div>
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} md={4}>
                <Card>
                  <CardContent>
                    <h3>Redirects Chart</h3>
                    <div ref={redirectsChartRef}>
                      <Pie data={redirectsData} />
                    </div>
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} md={4}>
                <Card>
                  <CardContent>
                    <h3>Protocol Chart</h3>
                    <div ref={protocolChartRef}>
                      <Pie data={protocolData} />
                    </div>
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} md={4}>
                <Card>
                  <CardContent>
                    <h3>Canonical Chart</h3>
                    <div ref={canonicalChartRef}>
                      <Pie data={canonicalData} />
                    </div>
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} md={10}>
                <Card>
                  <CardContent>
                    <h3>Line Chart</h3>
                    <div ref={lineChartRef}>
                      <Line data={lineData} />
                    </div>
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} md={10}>
                <Card>
                  <CardContent>
                    <h3>Bar Chart</h3>
                    <div ref={barChartRef}>
                      <Bar data={barData} />
                    </div>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
          </div>

          <Button onClick={handleDownloadPDF} variant="contained" color="primary">
            Download PDF
          </Button>
        </>

      )}


    </div>
  );
};

export default InternalLinkCounter;
