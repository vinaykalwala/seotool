import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import '../Css/File.css';
import { Pie, Bar, Line } from 'react-chartjs-2';
import 'chart.js/auto';
import CircularProgress from '@material-ui/core/CircularProgress';
import { makeStyles } from '@material-ui/core/styles'; 
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { Button } from '@mui/material';
import { Link } from 'react-router-dom';

import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend } from 'chart.js';
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

const useStyles = makeStyles((theme) => ({
  spinner: {
    color: '#36A2EB',
    marginTop: theme.spacing(2),
  },
}));

const Dashboard = () => {
  const classes = useStyles(); 

  const [url, setUrl] = useState('');
  const [internalLinksCount, setInternalLinksCount] = useState(null);
  const [externalLinksCount, setExternalLinksCount] = useState(null);
  const [metaTagsCount, setMetaTagsCount] = useState(null);
  const [backlinksCount, setBacklinksCount] = useState(null);
  const [internalLinks, setInternalLinks] = useState([]);
  const [externalLinks, setExternalLinks] = useState([]);
  const [totalCrawledLinks, setTotalCrawledLinks] = useState(null);
  const [htmlPagesCount, setHtmlPagesCount] = useState(null);
  const [nonHtmlFilesCount, setNonHtmlFilesCount] = useState(null);
  const [redirects, setRedirects] = useState([]);
  const [brokenLinks, setBrokenLinks] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [showLinks, setShowLinks] = useState(null); 
  const [dofollowInternalLinks, setDofollowInternalLinks] = useState([]);
  const [nofollowInternalLinks, setNofollowInternalLinks] = useState([]);
  const [canonicalLinks, setCanonicalLinks] = useState([]);
  const [nonCanonicalLinks, setNonCanonicalLinks] = useState([]);
  const [httpLinksCount, setHttpLinksCount] = useState(0);
  const [httpsLinksCount, setHttpsLinksCount] = useState(0);
  const [totalImages, setTotalImages] = useState(0);
  const canonicalChartRef = useRef(null);
  const brokenLinksChartRef = useRef(null);
  const htmlPagesChartRef = useRef(null);
  const redirectsChartRef = useRef(null);
  const protocolChartRef = useRef(null);
  const lineChartRef = useRef(null);
  const barChartRef = useRef(null);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [timerRunning, setTimerRunning] = useState(true);

  const timerRef = useRef(null);
  useEffect(() => {
    if (!url) return;

    setLoading(true);

    axios.get(`http://localhost:8000/overview/?url=${encodeURIComponent(url)}`)
      .then(response => {
        const {
          internal_links_count,
          external_links_count,
          meta_tags_count,
          backlinks_count,
          internal_links,
          external_links,
          total_crawled_links,
          html_pages_count,
          non_html_files_count,
          redirects,
          broken_links,
          dofollow_internal_links,
          nofollow_internal_links,
          canonical_links,
          non_canonical_links,
          total_images
        } = response.data;

        setInternalLinksCount(internal_links_count);
        setExternalLinksCount(external_links_count);
        setMetaTagsCount(meta_tags_count);
        setBacklinksCount(backlinks_count);
        setInternalLinks(internal_links);
        setExternalLinks(external_links);
        setTotalCrawledLinks(total_crawled_links);
        setHtmlPagesCount(html_pages_count);
        setNonHtmlFilesCount(non_html_files_count);
        setRedirects(redirects);
        setBrokenLinks(broken_links);
        setDofollowInternalLinks(dofollow_internal_links);
        setNofollowInternalLinks(nofollow_internal_links);
        setCanonicalLinks(canonical_links);
        setNonCanonicalLinks(non_canonical_links);
        setTotalImages(total_images);

        const httpLinks = internal_links.filter(link => link.startsWith('http://')).length +
                          external_links.filter(link => link.startsWith('http://')).length;
        const httpsLinks = internal_links.filter(link => link.startsWith('https://')).length +
                           external_links.filter(link => link.startsWith('https://')).length;

        setHttpLinksCount(httpLinks);
        setHttpsLinksCount(httpsLinks);

        setError(null);
      })
      .catch(error => {
        setError(error.response ? error.response.data.error : 'An error occurred');
        resetState();
      })
      .finally(() => {
        setLoading(false);
        setElapsedTime(0);
      });
  }, [url]);

  useEffect(() => {
    if (timerRunning) {
      timerRef.current = setInterval(() => {
        setElapsedTime((prevTime) => prevTime + 100);
      }, 100);
    } else {
      clearInterval(timerRef.current);
    }

    return () => clearInterval(timerRef.current);
  }, [timerRunning]);

  const resetState = () => {
    setInternalLinksCount(null);
    setExternalLinksCount(null);
    setMetaTagsCount(null);
    setBacklinksCount(null);
    setInternalLinks([]);
    setExternalLinks([]);
    setTotalCrawledLinks(null);
    setHtmlPagesCount(null);
    setNonHtmlFilesCount(null);
    setRedirects([]);
    setBrokenLinks([]);
    setHttpLinksCount(0);
    setHttpsLinksCount(0);
    setDofollowInternalLinks([]);
    setNofollowInternalLinks([]);
    setCanonicalLinks([]);
    setNonCanonicalLinks([]);
    setTotalImages(0);
  };

  const handleSearch = () => {
    resetState();
    setUrl(document.getElementById('urlInput').value);
  };

  useEffect(() => {
    return () => {
      if (brokenLinksChartRef.current && brokenLinksChartRef.current.chartInstance) {
        brokenLinksChartRef.current.chartInstance.destroy();
      }
      if (htmlPagesChartRef.current && htmlPagesChartRef.current.chartInstance) {
        htmlPagesChartRef.current.chartInstance.destroy();
      }
      if (redirectsChartRef.current && redirectsChartRef.current.chartInstance) {
        redirectsChartRef.current.chartInstance.destroy();
      }
      if (protocolChartRef.current && protocolChartRef.current.chartInstance) {
        protocolChartRef.current.chartInstance.destroy();
      }
      if (canonicalChartRef.current && canonicalChartRef.current.chartInstance) {
        canonicalChartRef.current.chartInstance.destroy();
      }
      if (barChartRef.current && barChartRef.current.chartInstance) {
        barChartRef.current.chartInstance.destroy();
      }
    };
  }, [brokenLinks, htmlPagesCount, nonHtmlFilesCount, redirects, httpLinksCount, httpsLinksCount]);

  const brokenLinksData = {
    labels: ['Broken Links', 'Non-Broken Links'],
    datasets: [
      {
        data: [brokenLinks.length || 0, (internalLinks.length + externalLinks.length - brokenLinks.length) || 0],
        backgroundColor: ['#FF6347', '#36A2EB'],
      },
    ],
  };

  const htmlPagesData = {
    labels: ['HTML Pages', 'Non-HTML Files'],
    datasets: [
      {
        data: [htmlPagesCount, nonHtmlFilesCount],
        backgroundColor: ['#FFD700', '#ADFF2F'],
      },
    ],
  };

  const redirectsData = {
    labels: ['Redirect Links', 'Non-Redirect Links'],
    datasets: [
      {
        data: [redirects.length, internalLinks.length + externalLinks.length - redirects.length],
        backgroundColor: ['#FFA500', '#9932CC'],
      },
    ],
  };

  const protocolData = {
    labels: ['HTTP Links', 'HTTPS Links'],
    datasets: [
      {
        data: [httpLinksCount, httpsLinksCount],
        backgroundColor: ['#FF4500', '#00FF00'],
      },
    ],
  };

  const canonicalData = {
    labels: ['Canonical Links', 'Non-Canonical Links'],
    datasets: [
      {
        data: [canonicalLinks.length, nonCanonicalLinks.length],
        backgroundColor: ['#b90790', '#e099d0'],
      },
    ],
  };

  const lineData = {
    labels: [
      'Internal Links', 
      'External Links', 
      'Meta Tags', 
      'Backlinks', 
      'Total Crawled Links', 
      'HTML Pages', 
      'Non-HTML Files', 
      'Redirects', 
      'Broken Links', 
      'HTTP Links', 
      'HTTPS Links', 
      'Dofollow Internal Links', 
      'Nofollow Internal Links',
      'Canonical Links',
      'Non-Canonical Links'
    ],
    datasets: [
      {
        label: 'Counts',
        data: [
          internalLinksCount,
          externalLinksCount,
          metaTagsCount,
          backlinksCount,
          totalCrawledLinks,
          htmlPagesCount,
          nonHtmlFilesCount,
          redirects.length,
          brokenLinks.length,
          httpLinksCount,
          httpsLinksCount,
          dofollowInternalLinks.length,
          nofollowInternalLinks.length,
          canonicalLinks.length,
          nonCanonicalLinks.length,
        ],
        backgroundColor: 'rgba(75,192,192,0.4)',
        borderColor: 'rgba(75,192,192,1)',
        borderWidth: 1,
        tension: 0.1,
      },
    ],
  };

  
  const barData = {
    labels: [
      'Internal Links', 
      'External Links', 
      'Meta Tags', 
      'Backlinks', 
      'Total Crawled Links', 
      'HTML Pages', 
      'Non-HTML Files', 
      'Redirects', 
      'Broken Links', 
      'HTTP Links', 
      'HTTPS Links', 
      'Dofollow Internal Links', 
      'Nofollow Internal Links',
      'Canonical Links',
      'Non-Canonical Links'
    ],
    datasets: [
      {
        label: 'Counts',
        data: [
          internalLinksCount,
          externalLinksCount,
          metaTagsCount,
          backlinksCount,
          totalCrawledLinks,
          htmlPagesCount,
          nonHtmlFilesCount,
          redirects.length,
          brokenLinks.length,
          httpLinksCount,
          httpsLinksCount,
          dofollowInternalLinks.length,
          nofollowInternalLinks.length,
          canonicalLinks.length,
          nonCanonicalLinks.length,
        ],
        backgroundColor: 'rgba(75,192,192,0.4)',
        borderColor: 'rgba(75,192,192,1)',
        borderWidth: 1,
      },
      // Add additional datasets here if needed
    ],
  };
    

  const toggleLinksVisibility = (type) => {
    setShowLinks((prevState) => (prevState === type ? null : type));
  };

  const exportPdf = () => {
    const charts = [
      { ref: brokenLinksChartRef, name: 'broken_links_chart' },
      { ref: htmlPagesChartRef, name: 'html_pages_chart' },
      { ref: redirectsChartRef, name: 'redirects_chart' },
      { ref: protocolChartRef, name: 'protocol_chart' },
      { ref: canonicalChartRef, name: 'canonical_chart' },
      { ref: lineChartRef, name: 'line_chart' },
      { ref: barChartRef, name: 'bar_chart' },
    ];

    const promises = charts.map(chart => {
      return html2canvas(chart.ref.current).then(canvas => {
        return { name: chart.name, canvas };
      });
    });

    Promise.all(promises).then(canvasArray => {
      const pdf = new jsPDF();

      canvasArray.forEach((canvasObj, index) => {
        const imgData = canvasObj.canvas.toDataURL('image/png');
        pdf.addImage(imgData, 'PNG', 10, 10, 180, 150);

        if (index < canvasArray.length - 1) {
          pdf.addPage();
        }
      });

      pdf.save('charts.pdf');
    });
  };

  const renderLoadingSpinner = () => (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
      <CircularProgress className={classes.spinner} size={80} />
    </div>
  );
  
  return (
    <div style={styles.dashboard}>
    <h1>Dashboard</h1>
    <div style={styles.form}>
      <input type="text" id="urlInput" placeholder="Enter URL" style={styles.input} />
      <Button variant="contained" color="primary" onClick={handleSearch}>Fetch Data</Button>
      <Button variant="contained" color="secondary" onClick={exportPdf}>Export to PDF</Button>
    </div>
    {loading ? renderLoadingSpinner() : (
      <div style={styles.results}>
        {error && <p style={styles.error}>{error}</p>}
        {!error && internalLinksCount !== null && (
          <div style={styles.cardContainer}>
            <div style={styles.card}>
              <p><strong>Elapsed Time:</strong> {elapsedTime / 1000} seconds</p>
            </div>
            <div style={styles.card}>
              <p><strong>Internal Links Count:</strong> {internalLinksCount}</p>
            </div>
            <div style={styles.card}>
              <p><strong>External Links Count:</strong> {externalLinksCount}</p>
            </div>
            <div style={styles.card}>
              <p><strong>Meta Tags Count:</strong> {metaTagsCount}</p>
            </div>
            <div style={styles.card}>
              <p><strong>Backlinks Count:</strong> {backlinksCount}</p>
            </div>
            <div style={styles.card}>
              <p><strong>Total Crawled Links:</strong> {totalCrawledLinks}</p>
            </div>
            <div style={styles.card}>
              <p><strong>HTML Pages Count:</strong> {htmlPagesCount}</p>
            </div>
            <div style={styles.card}>
              <p><strong>Non-HTML Files Count:</strong> {nonHtmlFilesCount}</p>
            </div>
            <div style={styles.card}>
              <p><strong>Total Images:</strong> {totalImages}</p>
            </div>
            <div style={styles.card}>
              <p>
                <strong>Internal Links:</strong> 
                <button onClick={() => toggleLinksVisibility('internal')}>Toggle</button>
              </p>
              {showLinks === 'internal' && (
                <ul>
                  {internalLinks.map((link, index) => (
                    <li key={index}>{link}</li>
                  ))}
                </ul>
              )}
            </div>
            <div style={styles.card}>
              <p>
                <strong>External Links:</strong> 
                <button onClick={() => toggleLinksVisibility('external')}>Toggle</button>
              </p>
              {showLinks === 'external' && (
                <ul>
                  {externalLinks.map((link, index) => (
                    <li key={index}>{link}</li>
                  ))}
                </ul>
              )}
            </div>
            <div style={styles.chartContainer}>
              <div style={styles.chartCard}>
                <h3>Broken Links Chart</h3>
                <Pie data={brokenLinksData} />
              </div>
              <div style={styles.chartCard}>
                <h3>HTML Pages Chart</h3>
                <Pie data={htmlPagesData} />
              </div>
            </div>
            <div style={styles.chartContainer}>
              <div style={styles.chartCard}>
                <h3>Line Chart</h3>
                <Line data={lineData} />
              </div>
              <div style={styles.chartCard}>
                <h3>Bar Chart</h3>
                <Bar data={barData} />
              </div>
            </div>
          </div>
        )}
      </div>
    )}
    <Button component={Link} to="/otherpage">Go to Other Page</Button>
  </div>
);
};

const styles = {
dashboard: {
  padding: '20px',
},
form: {
  marginBottom: '20px',
},
input: {
  marginRight: '10px',
},
results: {
  marginTop: '20px',
},
error: {
  color: 'red',
},
spinnerContainer: {
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  height: '100px',
},
spinner: {
  border: '8px solid rgba(0, 0, 0, 0.1)',
  borderRadius: '50%',
  borderTop: '8px solid #3498db',
  width: '50px',
  height: '50px',
  animation: 'spin 1s linear infinite',
},
cardContainer: {
  display: 'flex',
  flexWrap: 'wrap',
  gap: '10px',
},
card: {
  flex: '1 1 calc(25% - 10px)',
  boxSizing: 'border-box',
  padding: '20px',
  border: '1px solid #ddd',
  borderRadius: '8px',
  marginBottom: '10px',
},
chartContainer: {
  display: 'flex',
  flexWrap: 'wrap',
  gap: '10px',
},
chartCard: {
  flex: '1 1 calc(50% - 10px)',
  boxSizing: 'border-box',
  padding: '20px',
  border: '1px solid #ddd',
  borderRadius: '8px',
  marginBottom: '10px',
},
};

export default Dashboard;