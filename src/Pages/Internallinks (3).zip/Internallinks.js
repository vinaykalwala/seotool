import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import '../Css/File.css';
import { Pie, Bar } from 'react-chartjs-2';
import 'chart.js/auto'; // Correct import for Chart.js version 3 and above
import CircularProgress from '@material-ui/core/CircularProgress'; // Import CircularProgress from Material-UI
import { makeStyles } from '@material-ui/core/styles'; 
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';


const useStyles = makeStyles((theme) => ({
  spinner: {
    color: '#36A2EB', // Customize the color of the spinner
    marginTop: theme.spacing(2), // Adjust the margin top as needed
  },
}));

const InternalLinkCounter = () => {
  const classes = useStyles(); // Define classes using makeStyles

  const [url, setUrl] = useState('');
  const [internalLinksCount, setInternalLinksCount] = useState(null);
  const [externalLinksCount, setExternalLinksCount] = useState(null);
  const [metaTagsCount, setMetaTagsCount] = useState(null);
  const [backlinksCount, setBacklinksCount] = useState(null);
  const [internalLinks, setInternalLinks] = useState([]);
  const [externalLinks, setExternalLinks] = useState([]);
  const [totalCrawledLinks, setTotalCrawledLinks] = useState(null);
  const [htmlPagesCount, setHtmlPagesCount] = useState(null);
  const [nonHtmlFilesCount, setNonHtmlFilesCount] = useState(null);
  const [redirects, setRedirects] = useState([]);
  const [brokenLinks, setBrokenLinks] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [showLinks, setShowLinks] = useState(null); // State to control which links to display
  const [dofollowInternalLinks, setDofollowInternalLinks] = useState([]); // New state for dofollow links
  const [nofollowInternalLinks, setNofollowInternalLinks] = useState([]); // New state for nofollow links
  const [canonicalLinks, setCanonicalLinks] = useState([]); // New state for canonical links
  const [nonCanonicalLinks, setNonCanonicalLinks] = useState([]); // New state for non-canonical links
  const [httpLinksCount, setHttpLinksCount] = useState(0);
  const [httpsLinksCount, setHttpsLinksCount] = useState(0);
  const [totalImages, setTotalImages] = useState(0); // New state for total number of images
  const canonicalChartRef = useRef(null);
 const [data, setData] = useState({
    title_info: '',
    h1_info: [],
    word_count_info: 0,
  });
  const brokenLinksChartRef = useRef(null);
  const htmlPagesChartRef = useRef(null);
  const redirectsChartRef = useRef(null);
  const protocolChartRef = useRef(null);

  const barChartRef = useRef(null);
  const [elapsedTime, setElapsedTime] = useState(0); // State for tracking elapsed time
  const [timerRunning, setTimerRunning] = useState(true); // Ensure timer starts running initially

  const timerRef = useRef(null); // Reference for the timer
  useEffect(() => {
    if (!url) return;

    setLoading(true);

    axios.get(`http://localhost:8000/count-internal-links/?url=${encodeURIComponent(url)}`)
      .then(response => {
        const {
          internal_links_count,
          external_links_count,
          meta_tags_count,
          backlinks_count,
          internal_links,
          external_links,
          total_crawled_links,
          html_pages_count,
          non_html_files_count,
          redirects,
          broken_links,
          dofollow_internal_links = [], 
          nofollow_internal_links = [] ,
          canonical_links = [], 
          non_canonical_links = [],
          total_images = 0
        } = response.data;

        setInternalLinksCount(internal_links_count);
        setExternalLinksCount(external_links_count);
        setMetaTagsCount(meta_tags_count);
        setBacklinksCount(backlinks_count);
        setInternalLinks(internal_links);
        setExternalLinks(external_links);
        setTotalCrawledLinks(total_crawled_links);
        setHtmlPagesCount(html_pages_count);
        setNonHtmlFilesCount(non_html_files_count);
        setRedirects(redirects);
        setBrokenLinks(broken_links);
        setDofollowInternalLinks(dofollow_internal_links); // Set dofollow links
        setNofollowInternalLinks(nofollow_internal_links); // Set nofollow links
        setCanonicalLinks(canonical_links); // Set canonical links
        setNonCanonicalLinks(non_canonical_links); // Set non-canonical links
        setTotalImages(total_images); // Set total images count

        // Calculate HTTP and HTTPS links count
        const httpLinks = internal_links.filter(link => link.startsWith('http://')).length +
                          external_links.filter(link => link.startsWith('http://')).length;
        const httpsLinks = internal_links.filter(link => link.startsWith('https://')).length +
                           external_links.filter(link => link.startsWith('https://')).length;

        setHttpLinksCount(httpLinks);
        setHttpsLinksCount(httpsLinks);

        setError(null);
      })
      .catch(error => {
        setError(error.response ? error.response.data.error : 'An error occurred');
        setInternalLinksCount(null);
        setExternalLinksCount(null);
        setMetaTagsCount(null);
        setBacklinksCount(null);
        setInternalLinks([]);
        setExternalLinks([]);
        setTotalCrawledLinks(null);
        setHtmlPagesCount(null);
        setNonHtmlFilesCount(null);
        setRedirects([]);
        setBrokenLinks([]);
        setHttpLinksCount(0);
        setHttpsLinksCount(0);
        setDofollowInternalLinks([]); // Clear dofollow links
        setNofollowInternalLinks([]); // Clear nofollow links
        setCanonicalLinks([]); // Clear canonical links
        setNonCanonicalLinks([]); // Clear non-canonical links
        setTotalImages(0); // Clear total images count

      })
      .finally(() => {
        setLoading(false);
        setElapsedTime(0); // Reset the elapsed time
      });
  }, [url]);

  // Start the timer
  useEffect(() => {
    if (timerRunning) {
      timerRef.current = setInterval(() => {
        setElapsedTime((prevTime) => prevTime + 100); // Update elapsed time every 100ms
      }, 100);
    } else {
      clearInterval(timerRef.current); // Clear the interval when timer is not running
    }

    // Clean up function to clear the interval
    return () => clearInterval(timerRef.current);
  }, [timerRunning]);

  const handleSearch = () => {
    setInternalLinksCount(null);
    setExternalLinksCount(null);
    setMetaTagsCount(null);
    setBacklinksCount(null);
    setError(null);
    setInternalLinks([]);
    setExternalLinks([]);
    setTotalCrawledLinks(null);
    setHtmlPagesCount(null);
    setNonHtmlFilesCount(null);
    setRedirects([]);
    setBrokenLinks([]);
    setHttpLinksCount(0);
    setHttpsLinksCount(0);
    setDofollowInternalLinks([]); // Clear dofollow links
    setNofollowInternalLinks([]); // Clear nofollow links
    setTotalImages(0); // Clear total images count
    setDofollowInternalLinks([]); // Clear dofollow links
    setNofollowInternalLinks([]); // Clear nofollow links

    setUrl(document.getElementById('urlInput').value);
  };

  useEffect(() => {
    // Cleanup function to destroy chart instances if they exist
    return () => {
      if (brokenLinksChartRef.current && brokenLinksChartRef.current.chartInstance) {
        brokenLinksChartRef.current.chartInstance.destroy();
      }
      if (htmlPagesChartRef.current && htmlPagesChartRef.current.chartInstance) {
        htmlPagesChartRef.current.chartInstance.destroy();
      }
      if (redirectsChartRef.current && redirectsChartRef.current.chartInstance) {
        redirectsChartRef.current.chartInstance.destroy();
      }
      if (protocolChartRef.current && protocolChartRef.current.chartInstance) {
        protocolChartRef.current.chartInstance.destroy();
      }

      if (canonicalChartRef.current && canonicalChartRef.current.chartInstance) {
        canonicalChartRef.current.chartInstance.destroy();
      }
      if (barChartRef.current && barChartRef.current.chartInstance) {
        barChartRef.current.chartInstance.destroy();
      }
    };
  }, [brokenLinks, htmlPagesCount, nonHtmlFilesCount, redirects, httpLinksCount, httpsLinksCount]);

  // Data for Pie Charts
  const brokenLinksData = {
    labels: ['Broken Links', 'Non-Broken Links'],
    datasets: [
      {
        data: [brokenLinks.length, internalLinks.length + externalLinks.length - brokenLinks.length],
        backgroundColor: ['#FF6347', '#36A2EB'],
      },
    ],
  };

  const htmlPagesData = {
    labels: ['HTML Pages', 'Non-HTML Files'],
    datasets: [
      {
        data: [htmlPagesCount, nonHtmlFilesCount],
        backgroundColor: ['#FFD700', '#ADFF2F'],
      },
    ],
  };

  const redirectsData = {
    labels: ['Redirect Links', 'Non-Redirect Links'],
    datasets: [
      {
        data: [redirects.length, internalLinks.length + externalLinks.length - redirects.length],
        backgroundColor: ['#FFA500', '#9932CC'],
      },
    ],
  };

  const protocolData = {
    labels: ['HTTP Links', 'HTTPS Links'],
    datasets: [
      {
        data: [httpLinksCount, httpsLinksCount],
        backgroundColor: ['#FF4500', '#00FF00'],
      },
    ],
  };


  const canonicalData = {
    labels: ['Canonical Links', 'Non-Canonical Links'],
    datasets: [
      {
        data: [canonicalLinks.length, nonCanonicalLinks.length],
        backgroundColor: ['#b90790', '#e099d0'],
      },
    ],
  };




  const barData = {
    labels: [
      'Internal Links', 
      'External Links', 
      'Meta Tags', 
      'Backlinks', 
      'Total Crawled Links', 
      'HTML Pages', 
      'Non-HTML Files', 
      'Redirects', 
      'Broken Links', 
      'HTTP Links', 
      'HTTPS Links', 
      'Dofollow Internal Links', 
      'Nofollow Internal Links',
      'Canonical Links',
      'Non-Canonical Links'
    ],
    datasets: [
      {
        label: 'Counts',
        data: [
          internalLinksCount,
          externalLinksCount,
          metaTagsCount,
          backlinksCount,
          totalCrawledLinks,
          htmlPagesCount,
          nonHtmlFilesCount,
          redirects.length,
          brokenLinks.length,
          httpLinksCount,
          httpsLinksCount,
          dofollowInternalLinks.length,
          nofollowInternalLinks.length,
          canonicalLinks.length,
          nonCanonicalLinks.length
        ],
        backgroundColor: [
          '#FF5733', // Internal Links
          '#33FF57', // External Links
          '#3357FF', // Meta Tags
          '#FF33A1', // Backlinks
          '#FFBF33', // Total Crawled Links
          '#33FFBF', // HTML Pages
          '#BF33FF', // Non-HTML Files
          '#FFB833', // Redirects
          '#33BFFF', // Broken Links
          '#FF3333', // HTTP Links
          '#33FF33', // HTTPS Links
          '#33FFFF', // Dofollow Internal Links
          '#FF33FF', // Nofollow Internal Links
          '#FFD700', // Canonical Links
          '#d339d7'  // Non-Canonical Links
        ],
        borderColor: '#003f5c',
        borderWidth: 1,
      },
    ],
  };
  
  const pageRef = useRef();

  const generatePdf = async () => {
    const input = pageRef.current;
    const canvas = await html2canvas(input);
    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF('p', 'mm', 'a4');
    const imgProps = pdf.getImageProperties(imgData);
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
    pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
    pdf.save('page_content.pdf');

    // Open the PDF in a new window and print
    const pdfBlob = pdf.output('blob');
    const pdfUrl = URL.createObjectURL(pdfBlob);
    const newWindow = window.open(pdfUrl);
    newWindow.onload = () => {
      newWindow.print();
      URL.revokeObjectURL(pdfUrl); // Clean up the object URL after printing
    };
  };

  
  
  return (
    <div>
      <h3>Internal Pages</h3>
      <label htmlFor="urlInput" className="label">Enter URL:</label>
      <input type="url" id="urlInput" className="input" required />
      <button onClick={handleSearch} className="button">Search</button>
      {loading && <CircularProgress className={classes.spinner} />}
      {error && <p className="error">Error: {error}</p>}
      {!loading && (
        <div>




<div className="card-container" style={{ display: 'flex', flexWrap: 'wrap', gap: '16px' }}>
  <div className="row" style={{ display: 'flex', flexWrap: 'wrap', gap: '16px', width: '100%' }}>
    <div className="col-md-3" style={{ flex: '1 1 calc(25% - 16px)', boxSizing: 'border-box' }}>
      <div className="card" style={{ padding: '16px', backgroundColor: '#f4f4f4', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)' }}>
        <p>Total Backlinks</p>
        <p>{backlinksCount}</p>
      </div>
    </div>
    <div className="col-md-3" style={{ flex: '1 1 calc(25% - 16px)', boxSizing: 'border-box' }}>
      <div className="card" style={{ padding: '16px', backgroundColor: '#f4f4f4', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)' }}>
        <p>Total Crawled Links</p>
        <p>{totalCrawledLinks}</p>
      </div>
    </div>
    <div className="col-md-3" style={{ flex: '1 1 calc(25% - 16px)', boxSizing: 'border-box' }}>
      <div className="card" style={{ padding: '16px', backgroundColor: '#f4f4f4', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)' }}>
        <p>Total HTML Pages</p>
        <p>{htmlPagesCount}</p>
      </div>
    </div>
    <div className="col-md-3" style={{ flex: '1 1 calc(25% - 16px)', boxSizing: 'border-box' }}>
      <div className="card" style={{ padding: '16px', backgroundColor: '#f4f4f4', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)' }}>
        <p>Total Non-HTML Files</p>
        <p>{nonHtmlFilesCount}</p>
      </div>
    </div>
  </div>

  <div className="row" style={{ display: 'flex', flexWrap: 'wrap', gap: '16px', width: '100%' }}>
    <div className="col-md-3" style={{ flex: '1 1 calc(25% - 16px)', boxSizing: 'border-box' }}>
      <div className="card" style={{ padding: '16px', backgroundColor: '#f4f4f4', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)' }}>
        <p>Total Redirects</p>
        <p>{redirects.length}</p>
      </div>
    </div>
    <div className="col-md-3" style={{ flex: '1 1 calc(25% - 16px)', boxSizing: 'border-box' }}>
      <div className="card" style={{ padding: '16px', backgroundColor: '#f4f4f4', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)' }}>
        <p>Total Broken Links</p>
        <p>{brokenLinks.length}</p>
      </div>
    </div>
    <div className="col-md-3" style={{ flex: '1 1 calc(25% - 16px)', boxSizing: 'border-box' }}>
      <div className="card" style={{ padding: '16px', backgroundColor: '#f4f4f4', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)' }}>
        <p>HTTP Links</p>
        <p>{httpLinksCount}</p>
      </div>
    </div>
    <div className="col-md-3" style={{ flex: '1 1 calc(25% - 16px)', boxSizing: 'border-box' }}>
      <div className="card" style={{ padding: '16px', backgroundColor: '#f4f4f4', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)' }}>
        <p>HTTPS Links</p>
        <p>{httpsLinksCount}</p>
      </div>
    </div>
  </div>

  <div className="row" style={{ display: 'flex', flexWrap: 'wrap', gap: '16px', width: '100%' }}>
    <div className="col-md-3" style={{ flex: '1 1 calc(25% - 16px)', boxSizing: 'border-box' }}>
      <div className="card" style={{ padding: '16px', backgroundColor: '#f4f4f4', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)' }}>
        <p>Dofollow Internal Links</p>
        <p>{dofollowInternalLinks.length}</p>
      </div>
    </div>
    <div className="col-md-3" style={{ flex: '1 1 calc(25% - 16px)', boxSizing: 'border-box' }}>
      <div className="card" style={{ padding: '16px', backgroundColor: '#f4f4f4', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)' }}>
        <p>Nofollow Internal Links</p>
        <p>{nofollowInternalLinks.length}</p>
      </div>
    </div>
    <div className="col-md-3" style={{ flex: '1 1 calc(25% - 16px)', boxSizing: 'border-box' }}>
      <div className="card" style={{ padding: '16px', backgroundColor: '#f4f4f4', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)' }}>
        <p>Canonical Links</p>
        <p>{canonicalLinks.length}</p>
      </div>
    </div>
    <div className="col-md-3" style={{ flex: '1 1 calc(25% - 16px)', boxSizing: 'border-box' }}>
      <div className="card" style={{ padding: '16px', backgroundColor: '#f4f4f4', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)' }}>
        <p>Non-Canonical Links</p>
        <p>{nonCanonicalLinks.length}</p>
      </div>
    </div>
  </div>






<br></br>

  <div className="card">
    <h3>Charts</h3>
    <div className="chart">
      <p>Broken Links</p>
      <Pie data={brokenLinksData} ref={brokenLinksChartRef} />
    </div>
    </div>
    <div className="card">

    <div className="chart">
      <p>HTML Pages vs Non-HTML Files</p>
      <Pie data={htmlPagesData} ref={htmlPagesChartRef} />
    </div>
    </div>
    <div className="card">

    <div className="chart">
      <p>Redirects</p>
      <Pie data={redirectsData} ref={redirectsChartRef} />
    </div>
    </div>

    <div className="card">

    <div className="chart">
      <p>HTTP vs HTTPS Links</p>
      <Pie data={protocolData} ref={protocolChartRef} />
    </div>
    </div>
    <div className="card">

    <div className="chart">
      <p>Canonical vs Non Canonical Links</p>
      <Pie data={canonicalData} ref={canonicalChartRef} />
    </div>
    </div>
 
</div>
<div className="col-md-10">

<div className="chart">
  <h5>Counts of Various Metrics</h5>
  <Bar data={barData} ref={barChartRef} />
</div>
</div>

          <button onClick={generatePdf}>Generate PDF</button>
          <button onClick={generatePdf} className="button">Generate and Print PDF</button>

        </div>
      )}
    </div>
  );
};

export default InternalLinkCounter;
