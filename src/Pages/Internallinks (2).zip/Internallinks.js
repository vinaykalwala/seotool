import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import '../Css/File.css';
import { Pie, Bar } from 'react-chartjs-2';
import 'chart.js/auto'; // Correct import for Chart.js version 3 and above
import CircularProgress from '@material-ui/core/CircularProgress'; // Import CircularProgress from Material-UI
import { makeStyles } from '@material-ui/core/styles'; 
import jsPDF from 'jspdf';

const useStyles = makeStyles((theme) => ({
  spinner: {
    color: '#36A2EB', // Customize the color of the spinner
    marginTop: theme.spacing(2), // Adjust the margin top as needed
  },
}));

const InternalLinkCounter = () => {
  const classes = useStyles(); // Define classes using makeStyles

  const [url, setUrl] = useState('');
  const [internalLinksCount, setInternalLinksCount] = useState(null);
  const [externalLinksCount, setExternalLinksCount] = useState(null);
  const [metaTagsCount, setMetaTagsCount] = useState(null);
  const [backlinksCount, setBacklinksCount] = useState(null);
  const [internalLinks, setInternalLinks] = useState([]);
  const [externalLinks, setExternalLinks] = useState([]);
  const [totalCrawledLinks, setTotalCrawledLinks] = useState(null);
  const [htmlPagesCount, setHtmlPagesCount] = useState(null);
  const [nonHtmlFilesCount, setNonHtmlFilesCount] = useState(null);
  const [redirects, setRedirects] = useState([]);
  const [brokenLinks, setBrokenLinks] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [showLinks, setShowLinks] = useState(null); // State to control which links to display
  const [dofollowInternalLinks, setDofollowInternalLinks] = useState([]); // New state for dofollow links
  const [nofollowInternalLinks, setNofollowInternalLinks] = useState([]); // New state for nofollow links
  const [canonicalLinks, setCanonicalLinks] = useState([]); // New state for canonical links
  const [nonCanonicalLinks, setNonCanonicalLinks] = useState([]); // New state for non-canonical links
  const [httpLinksCount, setHttpLinksCount] = useState(0);
  const [httpsLinksCount, setHttpsLinksCount] = useState(0);
  const [totalImages, setTotalImages] = useState(0); // New state for total number of images
  const canonicalChartRef = useRef(null);
 const [data, setData] = useState({
    title_info: '',
    h1_info: [],
    word_count_info: 0,
  });
  const brokenLinksChartRef = useRef(null);
  const htmlPagesChartRef = useRef(null);
  const redirectsChartRef = useRef(null);
  const protocolChartRef = useRef(null);

  const barChartRef = useRef(null);
  const [elapsedTime, setElapsedTime] = useState(0); // State for tracking elapsed time
  const [timerRunning, setTimerRunning] = useState(true); // Ensure timer starts running initially

  const timerRef = useRef(null); // Reference for the timer
  useEffect(() => {
    if (!url) return;

    setLoading(true);

    axios.get(`http://localhost:8000/count-internal-links/?url=${encodeURIComponent(url)}`)
      .then(response => {
        const {
          internal_links_count,
          external_links_count,
          meta_tags_count,
          backlinks_count,
          internal_links,
          external_links,
          total_crawled_links,
          html_pages_count,
          non_html_files_count,
          redirects,
          broken_links,
          dofollow_internal_links = [], 
          nofollow_internal_links = [] ,
          canonical_links = [], 
          non_canonical_links = [],
          total_images = 0
        } = response.data;

        setInternalLinksCount(internal_links_count);
        setExternalLinksCount(external_links_count);
        setMetaTagsCount(meta_tags_count);
        setBacklinksCount(backlinks_count);
        setInternalLinks(internal_links);
        setExternalLinks(external_links);
        setTotalCrawledLinks(total_crawled_links);
        setHtmlPagesCount(html_pages_count);
        setNonHtmlFilesCount(non_html_files_count);
        setRedirects(redirects);
        setBrokenLinks(broken_links);
        setDofollowInternalLinks(dofollow_internal_links); // Set dofollow links
        setNofollowInternalLinks(nofollow_internal_links); // Set nofollow links
        setCanonicalLinks(canonical_links); // Set canonical links
        setNonCanonicalLinks(non_canonical_links); // Set non-canonical links
        setTotalImages(total_images); // Set total images count

        // Calculate HTTP and HTTPS links count
        const httpLinks = internal_links.filter(link => link.startsWith('http://')).length +
                          external_links.filter(link => link.startsWith('http://')).length;
        const httpsLinks = internal_links.filter(link => link.startsWith('https://')).length +
                           external_links.filter(link => link.startsWith('https://')).length;

        setHttpLinksCount(httpLinks);
        setHttpsLinksCount(httpsLinks);

        setError(null);
      })
      .catch(error => {
        setError(error.response ? error.response.data.error : 'An error occurred');
        setInternalLinksCount(null);
        setExternalLinksCount(null);
        setMetaTagsCount(null);
        setBacklinksCount(null);
        setInternalLinks([]);
        setExternalLinks([]);
        setTotalCrawledLinks(null);
        setHtmlPagesCount(null);
        setNonHtmlFilesCount(null);
        setRedirects([]);
        setBrokenLinks([]);
        setHttpLinksCount(0);
        setHttpsLinksCount(0);
        setDofollowInternalLinks([]); // Clear dofollow links
        setNofollowInternalLinks([]); // Clear nofollow links
        setCanonicalLinks([]); // Clear canonical links
        setNonCanonicalLinks([]); // Clear non-canonical links
        setTotalImages(0); // Clear total images count

      })
      .finally(() => {
        setLoading(false);
        setElapsedTime(0); // Reset the elapsed time
      });
  }, [url]);

  // Start the timer
  useEffect(() => {
    if (timerRunning) {
      timerRef.current = setInterval(() => {
        setElapsedTime((prevTime) => prevTime + 100); // Update elapsed time every 100ms
      }, 100);
    } else {
      clearInterval(timerRef.current); // Clear the interval when timer is not running
    }

    // Clean up function to clear the interval
    return () => clearInterval(timerRef.current);
  }, [timerRunning]);

  const handleSearch = () => {
    setInternalLinksCount(null);
    setExternalLinksCount(null);
    setMetaTagsCount(null);
    setBacklinksCount(null);
    setError(null);
    setInternalLinks([]);
    setExternalLinks([]);
    setTotalCrawledLinks(null);
    setHtmlPagesCount(null);
    setNonHtmlFilesCount(null);
    setRedirects([]);
    setBrokenLinks([]);
    setHttpLinksCount(0);
    setHttpsLinksCount(0);
    setDofollowInternalLinks([]); // Clear dofollow links
    setNofollowInternalLinks([]); // Clear nofollow links
    setTotalImages(0); // Clear total images count
    setDofollowInternalLinks([]); // Clear dofollow links
    setNofollowInternalLinks([]); // Clear nofollow links

    setUrl(document.getElementById('urlInput').value);
  };

  useEffect(() => {
    // Cleanup function to destroy chart instances if they exist
    return () => {
      if (brokenLinksChartRef.current && brokenLinksChartRef.current.chartInstance) {
        brokenLinksChartRef.current.chartInstance.destroy();
      }
      if (htmlPagesChartRef.current && htmlPagesChartRef.current.chartInstance) {
        htmlPagesChartRef.current.chartInstance.destroy();
      }
      if (redirectsChartRef.current && redirectsChartRef.current.chartInstance) {
        redirectsChartRef.current.chartInstance.destroy();
      }
      if (protocolChartRef.current && protocolChartRef.current.chartInstance) {
        protocolChartRef.current.chartInstance.destroy();
      }

      if (canonicalChartRef.current && canonicalChartRef.current.chartInstance) {
        canonicalChartRef.current.chartInstance.destroy();
      }
      if (barChartRef.current && barChartRef.current.chartInstance) {
        barChartRef.current.chartInstance.destroy();
      }
    };
  }, [brokenLinks, htmlPagesCount, nonHtmlFilesCount, redirects, httpLinksCount, httpsLinksCount]);

  // Data for Pie Charts
  const brokenLinksData = {
    labels: ['Broken Links', 'Non-Broken Links'],
    datasets: [
      {
        data: [brokenLinks.length, internalLinks.length + externalLinks.length - brokenLinks.length],
        backgroundColor: ['#FF6347', '#36A2EB'],
      },
    ],
  };

  const htmlPagesData = {
    labels: ['HTML Pages', 'Non-HTML Files'],
    datasets: [
      {
        data: [htmlPagesCount, nonHtmlFilesCount],
        backgroundColor: ['#FFD700', '#ADFF2F'],
      },
    ],
  };

  const redirectsData = {
    labels: ['Redirect Links', 'Non-Redirect Links'],
    datasets: [
      {
        data: [redirects.length, internalLinks.length + externalLinks.length - redirects.length],
        backgroundColor: ['#FFA500', '#9932CC'],
      },
    ],
  };

  const protocolData = {
    labels: ['HTTP Links', 'HTTPS Links'],
    datasets: [
      {
        data: [httpLinksCount, httpsLinksCount],
        backgroundColor: ['#FF4500', '#00FF00'],
      },
    ],
  };


  const canonicalData = {
    labels: ['Canonical Links', 'Non-Canonical Links'],
    datasets: [
      {
        data: [canonicalLinks.length, nonCanonicalLinks.length],
        backgroundColor: ['#b90790', '#e099d0'],
      },
    ],
  };




  const barData = {
    labels: [
      'Internal Links', 
      'External Links', 
      'Meta Tags', 
      'Backlinks', 
      'Total Crawled Links', 
      'HTML Pages', 
      'Non-HTML Files', 
      'Redirects', 
      'Broken Links', 
      'HTTP Links', 
      'HTTPS Links', 
      'Dofollow Internal Links', 
      'Nofollow Internal Links',
      'Canonical Links',
      'Non-Canonical Links'
    ],
    datasets: [
      {
        label: 'Counts',
        data: [
          internalLinksCount,
          externalLinksCount,
          metaTagsCount,
          backlinksCount,
          totalCrawledLinks,
          htmlPagesCount,
          nonHtmlFilesCount,
          redirects.length,
          brokenLinks.length,
          httpLinksCount,
          httpsLinksCount,
          dofollowInternalLinks.length,
          nofollowInternalLinks.length,
          canonicalLinks.length,
          nonCanonicalLinks.length
        ],
        backgroundColor: [
          '#FF5733', // Internal Links
          '#33FF57', // External Links
          '#3357FF', // Meta Tags
          '#FF33A1', // Backlinks
          '#FFBF33', // Total Crawled Links
          '#33FFBF', // HTML Pages
          '#BF33FF', // Non-HTML Files
          '#FFB833', // Redirects
          '#33BFFF', // Broken Links
          '#FF3333', // HTTP Links
          '#33FF33', // HTTPS Links
          '#33FFFF', // Dofollow Internal Links
          '#FF33FF', // Nofollow Internal Links
          '#FFD700', // Canonical Links
          '#d339d7'  // Non-Canonical Links
        ],
        borderColor: '#003f5c',
        borderWidth: 1,
      },
    ],
  };
  const generatePdf = () => {
    const doc = new jsPDF();
    doc.setFontSize(18);
    doc.text('Internal Link Counter Report', 14, 22);

    const addPieChart = (chartRef, x, y) => {
      if (chartRef.current && chartRef.current.chartInstance?.canvas) {
        const canvas = chartRef.current.chartInstance.canvas;
        const imageData = canvas.toDataURL('image/png');
        doc.addImage(imageData, 'PNG', x, y, 100, 100);
      }
    };

    addPieChart(brokenLinksChartRef, 14, 30);
    addPieChart(htmlPagesChartRef, 120, 30);
    addPieChart(redirectsChartRef, 14, 140);
    addPieChart(protocolChartRef, 120, 140);
    addPieChart(canonicalChartRef, 120, 140);


    // Add Bar Chart to PDF
    if (barChartRef.current && barChartRef.current.chartInstance?.canvas) {
      const canvas = barChartRef.current.chartInstance.canvas;
      const imageData = canvas.toDataURL('image/png');
      doc.addImage(imageData, 'PNG', 14, 250, 180, 120);
    }

    doc.save('internal_link_counter_report.pdf');
  };

  return (
    <div>
      <h3>Internal Pages</h3>
      <label htmlFor="urlInput" className="label">Enter URL:</label>
      <input type="url" id="urlInput" className="input" required />
      <button onClick={handleSearch} className="button">Search</button>
      {loading && <CircularProgress className={classes.spinner} />}
      {error && <p className="error">Error: {error}</p>}
      {!loading && (
        <div>
          <div className="metrics">
            <p>Total Internal Links: {internalLinksCount}</p>
            <p>Total External Links: {externalLinksCount}</p>
            <p>Total Meta Tags: {metaTagsCount}</p>
            <p>Total Backlinks: {backlinksCount}</p>
            <p>Total Crawled Links: {totalCrawledLinks}</p>
            <p>Total HTML Pages: {htmlPagesCount}</p>
            <p>Total Non-HTML Files: {nonHtmlFilesCount}</p>
            <p>Total Redirects: {redirects.length}</p>
            <p>Total Broken Links: {brokenLinks.length}</p>
            <p>HTTP Links: {httpLinksCount}</p>
            <p>HTTPS Links: {httpsLinksCount}</p>
            <p>Dofollow Internal Links: {dofollowInternalLinks.length}</p>
            <p>Nofollow Internal Links: {nofollowInternalLinks.length}</p>
            
            <p>Elapsed Time: {(elapsedTime / 1000).toFixed(2)} seconds</p>
            <p>Total Images: {totalImages}</p>
            <h2>Canonical Links Count: {canonicalLinks.length}</h2> {/* Display count of canonical links */}
            <h2>Non-Canonical Links Count: {nonCanonicalLinks.length}</h2> {/* Display count of non-canonical links */}
            <h3>Canonical Links</h3>
          <ul>
            {canonicalLinks.map((link, index) => (
              <li key={index}><a href={link} target="_blank" rel="noopener noreferrer">{link}</a></li>
            ))}
          </ul>

          <h3>Non-Canonical Links</h3>
          <ul>
            {nonCanonicalLinks.map((link, index) => (
              <li key={index}><a href={link} target="_blank" rel="noopener noreferrer">{link}</a></li>
            ))}
          </ul>

          </div>



      
  














          <div className="charts">
            <div className="chart">
              <h5>Broken Links</h5>
              <Pie data={brokenLinksData} ref={brokenLinksChartRef} />
            </div>
            <div className="chart">
              <h6>HTML Pages vs Non-HTML Files</h6>
              <Pie data={htmlPagesData} ref={htmlPagesChartRef} />
            </div>
            <div className="chart">
              <h5>Redirects</h5>
              <Pie data={redirectsData} ref={redirectsChartRef} />
            </div>
            <div className="chart">
              <h5>HTTP vs HTTPS Links</h5>
              <Pie data={protocolData} ref={protocolChartRef} />
            </div>
            <div className="chart">
              <h5>Canonical vs Non Canonical Links</h5>
              <Pie data={canonicalData} ref={canonicalChartRef} />
            </div>
            <div className="chart">
              <h5>Counts of Various Metrics</h5>
              <Bar data={barData} ref={barChartRef} />
            </div>
           
       
          </div>
          <button onClick={generatePdf}>Generate PDF</button>
        </div>
      )}
    </div>
  );
};

export default InternalLinkCounter;
