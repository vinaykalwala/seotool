import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import '../Css/File.css';
import { Pie, Bar, Line } from 'react-chartjs-2';
import 'chart.js/auto';
import CircularProgress from '@material-ui/core/CircularProgress';
import { makeStyles } from '@material-ui/core/styles';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { Button, Card, CardContent, CardHeader, Grid } from '@mui/material';
import { Link } from 'react-router-dom';
import { Typography } from '@mui/material';
import { Container, List, ListItem, ListItemText } from '@mui/material';
import Dropdown from 'react-bootstrap/Dropdown';
import DropdownButton from 'react-bootstrap/DropdownButton';
import { MDBAccordion, MDBAccordionItem } from 'mdb-react-ui-kit';

import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend } from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend);

const useStyles = makeStyles((theme) => ({
  spinner: {
    color: '#36A2EB',
    marginTop: theme.spacing(2),
  },
}));

const InternalLinkCounter = () => {
  const classes = useStyles();

  const [url, setUrl] = useState('');
  const [internalLinksCount, setInternalLinksCount] = useState(null);
  const [externalLinksCount, setExternalLinksCount] = useState(null);
  const [metaTagsCount, setMetaTagsCount] = useState(null);
  const [backlinksCount, setBacklinksCount] = useState(null);
  const [internalLinks, setInternalLinks] = useState([]);
  const [externalLinks, setExternalLinks] = useState([]);
  const [totalCrawledLinks, setTotalCrawledLinks] = useState(null);
  const [htmlPagesCount, setHtmlPagesCount] = useState(null);
  const [nonHtmlFilesCount, setNonHtmlFilesCount] = useState(null);
  const [redirects, setRedirects] = useState([]);
  const [brokenLinks, setBrokenLinks] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [showLinks, setShowLinks] = useState(null);
  const [dofollowInternalLinks, setDofollowInternalLinks] = useState([]);
  const [nofollowInternalLinks, setNofollowInternalLinks] = useState([]);
  const [canonicalLinks, setCanonicalLinks] = useState([]);
  const [nonCanonicalLinks, setNonCanonicalLinks] = useState([]);
  const [httpLinksCount, setHttpLinksCount] = useState(0);
  const [httpsLinksCount, setHttpsLinksCount] = useState(0);
  const [totalImages, setTotalImages] = useState(0);
  const canonicalChartRef = useRef(null);
  const brokenLinksChartRef = useRef(null);
  const htmlPagesChartRef = useRef(null);
  const redirectsChartRef = useRef(null);
  const protocolChartRef = useRef(null);
  const lineChartRef = useRef(null);
  const barChartRef = useRef(null);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [timerRunning, setTimerRunning] = useState(true);
  const timerRef = useRef(null);



  const handleButtonClick = () => {
    localStorage.setItem('internalLinks', JSON.stringify(internalLinks));
  };


  const handleButtonClick1 = () => {
    localStorage.setItem('externallinks', JSON.stringify(externalLinks));
  };




  useEffect(() => {
    if (!url) return;

    setLoading(true);

    axios.get(`http://localhost:8000/overview/?url=${encodeURIComponent(url)}`)
      .then(response => {
        const {
          internal_links_count,
          external_links_count,
          meta_tags_count,
          backlinks_count,
          internal_links,
          external_links,
          total_crawled_links,
          html_pages_count,
          non_html_files_count,
          redirects,
          broken_links,
          dofollow_internal_links = [],
          nofollow_internal_links = [],
          canonical_links = [],
          non_canonical_links = [],
          total_images = 0
        } = response.data;

        setInternalLinksCount(internal_links_count);
        setExternalLinksCount(external_links_count);
        setMetaTagsCount(meta_tags_count);
        setBacklinksCount(backlinks_count);
        setInternalLinks(internal_links);
        setExternalLinks(external_links);
        setTotalCrawledLinks(total_crawled_links);
        setHtmlPagesCount(html_pages_count);
        setNonHtmlFilesCount(non_html_files_count);
        setRedirects(redirects);
        setBrokenLinks(broken_links);
        setDofollowInternalLinks(dofollow_internal_links);
        setNofollowInternalLinks(nofollow_internal_links);
        setCanonicalLinks(canonical_links);
        setNonCanonicalLinks(non_canonical_links);
        setTotalImages(total_images);

        const httpLinks = internal_links.filter(link => link.startsWith('http://')).length +
                          external_links.filter(link => link.startsWith('http://')).length;
        const httpsLinks = internal_links.filter(link => link.startsWith('https://')).length +
                           external_links.filter(link => link.startsWith('https://')).length;

        setHttpLinksCount(httpLinks);
        setHttpsLinksCount(httpsLinks);

        setError(null);
      })
      .catch(error => {
        setError(error.response ? error.response.data.error : 'An error occurred');
        setInternalLinksCount(null);
        setExternalLinksCount(null);
        setMetaTagsCount(null);
        setBacklinksCount(null);
        setInternalLinks([]);
        setExternalLinks([]);
        setTotalCrawledLinks(null);
        setHtmlPagesCount(null);
        setNonHtmlFilesCount(null);
        setRedirects([]);
        setBrokenLinks([]);
        setHttpLinksCount(0);
        setHttpsLinksCount(0);
        setDofollowInternalLinks([]);
        setNofollowInternalLinks([]);
        setCanonicalLinks([]);
        setNonCanonicalLinks([]);
        setTotalImages(0);
      })
      .finally(() => {
        setLoading(false);
        setElapsedTime(0);
      });
  }, [url]);

  useEffect(() => {
    if (timerRunning) {
      timerRef.current = setInterval(() => {
        setElapsedTime((prevTime) => prevTime + 100);
      }, 100);
    } else {
      clearInterval(timerRef.current);
    }

    return () => clearInterval(timerRef.current);
  }, [timerRunning]);

  const handleSearch = () => {
    setInternalLinksCount(null);
    setExternalLinksCount(null);
    setMetaTagsCount(null);
    setBacklinksCount(null);
    setError(null);
    setInternalLinks([]);
    setExternalLinks([]);
    setTotalCrawledLinks(null);
    setHtmlPagesCount(null);
    setNonHtmlFilesCount(null);
    setRedirects([]);
    setBrokenLinks([]);
    setHttpLinksCount(0);
    setHttpsLinksCount(0);
    setDofollowInternalLinks([]);
    setNofollowInternalLinks([]);
    setTotalImages(0);
    setUrl(document.getElementById('urlInput').value);
  };

  useEffect(() => {
    const options = {
      responsive: true,
      plugins: {
        legend: {
          position: 'top',
        },
        title: {
          display: true,
          text: 'Counts of Various Metrics',
        },
      },
    };

    return () => {
      if (brokenLinksChartRef.current && brokenLinksChartRef.current.chartInstance) {
        brokenLinksChartRef.current.chartInstance.destroy();
      }
      if (htmlPagesChartRef.current && htmlPagesChartRef.current.chartInstance) {
        htmlPagesChartRef.current.chartInstance.destroy();
      }
      if (redirectsChartRef.current && redirectsChartRef.current.chartInstance) {
        redirectsChartRef.current.chartInstance.destroy();
      }
      if (protocolChartRef.current && protocolChartRef.current.chartInstance) {
        protocolChartRef.current.chartInstance.destroy();
      }
      if (canonicalChartRef.current && canonicalChartRef.current.chartInstance) {
        canonicalChartRef.current.chartInstance.destroy();
      }
      if (barChartRef.current && barChartRef.current.chartInstance) {
        barChartRef.current.chartInstance.destroy();
      }
    };
  }, [brokenLinks, htmlPagesCount, nonHtmlFilesCount, redirects, httpLinksCount, httpsLinksCount]);

  const brokenLinksData = {
    labels: ['Broken Links', 'Non-Broken Links'],
    datasets: [
      {
        data: [brokenLinks.length || 0, (internalLinks.length + externalLinks.length - brokenLinks.length) || 0],
        backgroundColor: ['#FF6347', '#36A2EB'],
      },
    ],
  };

  const htmlPagesData = {
    labels: ['HTML Pages', 'Non-HTML Files'],
    datasets: [
      {
        data: [htmlPagesCount, nonHtmlFilesCount],
        backgroundColor: ['#FFD700', '#ADFF2F'],
      },
    ],
  };

  const redirectsData = {
    labels: ['Redirect Links', 'Non-Redirect Links'],
    datasets: [
      {
        data: [redirects.length, internalLinks.length + externalLinks.length - redirects.length],
        backgroundColor: ['#FFA500', '#9932CC'],
      },
    ],
  };

  const protocolData = {
    labels: ['HTTP Links', 'HTTPS Links'],
    datasets: [
      {
        data: [httpLinksCount, httpsLinksCount],
        backgroundColor: ['#DC143C', '#00FA9A'],
      },
    ],
  };

  const canonicalData = {
    labels: ['Canonical Links', 'Non-Canonical Links'],
    datasets: [
      {
        data: [canonicalLinks.length, nonCanonicalLinks.length],
        backgroundColor: ['#0000FF', '#008080'],
      },
    ],
  };

  const barData = {
    labels: [
      'Internal Links',
      'External Links',
      'Meta Tags',
      'Backlinks',
      'Total Crawled Links',
      'HTML Pages',
      'Non-HTML Files',
      'Total Images'
    ],
    datasets: [
      {
        label: 'Counts',
        data: [
          internalLinksCount,
          externalLinksCount,
          metaTagsCount,
          backlinksCount,
          totalCrawledLinks,
          htmlPagesCount,
          nonHtmlFilesCount,
          totalImages
        ],
        backgroundColor: [
          '#36A2EB',
          '#FF6384',
          '#4BC0C0',
          '#FFCE56',
          '#8A2BE2',
          '#D2691E',
          '#DC143C',
          '#00FA9A'
        ],
      },
    ],
  };
  

  const lineData = {
    labels: [
      'Internal Links',
      'External Links',
      'Meta Tags',
      'Backlinks',
      'Total Crawled Links',
      'HTML Pages',
      'Non-HTML Files',
      'Total Images'
    ],
    datasets: [
      {
        label: 'Counts',
        data: [
          internalLinksCount,
          externalLinksCount,
          metaTagsCount,
          backlinksCount,
          totalCrawledLinks,
          htmlPagesCount,
          nonHtmlFilesCount,
          totalImages
        ],
        fill: false,
        borderColor: '#36A2EB',
      },
    ],
  };
  

  const handleDownloadPDF = () => {
    const elementsToCapture = [
      { ref: brokenLinksChartRef, id: 'brokenLinksChart' },
      { ref: htmlPagesChartRef, id: 'htmlPagesChart' },
      { ref: redirectsChartRef, id: 'redirectsChart' },
      { ref: protocolChartRef, id: 'protocolChart' },
      { ref: canonicalChartRef, id: 'canonicalChart' },
      { ref: lineChartRef, id: 'lineChart' },
      { ref: barChartRef, id: 'barChart' }
    ];

    const capturedElements = [];

    const captureNextElement = (index) => {
      if (index >= elementsToCapture.length) {
        const doc = new jsPDF();
        capturedElements.forEach(({ canvas, id }) => {
          const imgData = canvas.toDataURL('image/png');
          doc.addImage(imgData, 'PNG', 10, 10, 180, 120);
          doc.addPage();
        });
        doc.save('charts.pdf');
        return;
      }

      const { ref, id } = elementsToCapture[index];
      const element = ref.current;

      if (!element) {
        captureNextElement(index + 1);
        return;
      }

      html2canvas(element)
        .then((canvas) => {
          capturedElements.push({ canvas, id });
          captureNextElement(index + 1);
        })
        .catch((error) => {
          console.error(`Error capturing ${id}:`, error);
          captureNextElement(index + 1);
        });
    };

    captureNextElement(0);
  };

  const toggleLinks = (type) => {
    setShowLinks((prevShowLinks) => (prevShowLinks === type ? null : type));
  };



  const SummaryCard = ({ title, value }) => (
    <Card sx={{ minWidth: 275, marginBottom: 2 }}>
      <CardContent>
        <Typography variant="body1" color="textSecondary">
          {title}
        </Typography>
        <Typography variant="h6" component="div">
          {value}
        </Typography>
      </CardContent>
    </Card>

  )
  
  return (
    <div className="App">

<DropdownButton className="dropdown-button" id="dropdown-basic-button" title="Dropdown button">
<Dropdown.Item href="#/action-1">Action</Dropdown.Item>
      <Dropdown.Item href="/admin/fullcontent/internallinks/internallinksseperate">Internal links</Dropdown.Item>
      <Dropdown.Item href="#/action-3">External links</Dropdown.Item>
      <Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
      <Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
      <Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
      <Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
      <Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
      <Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
      <Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
      <Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
    </DropdownButton>
      <Card className="card">
        <CardHeader title="Crawl your website" />
        <div className="container">
        
        <div className="row">
        <div className="col-md-6">
  
  
        <div className="testimonial-card">
        <div className="speech-bubble">
          <h2>Awesome, enough said. really</h2>
          <p>
            Easy usability, solving real life problems. easy to implement. most of the cases has the fails and settings possibilities you right away need. never fails to impress.
          </p>
          <p className="author">Oliver Q,</p>
          <p className="job-title">Geschäftsführung Kreation/Art direction, Small-Business</p>
          <div className="stars">
            {[...Array(5)].map((_, i) => (
              <span key={i} className="star">⭐</span>
            ))}
          </div>
        </div>
      </div>
  </div>
  <div className="col-md-6">
  
  
        <div className="testimonial-card">
        <div className="speech-bubble">
          <h2>Awesome, enough said. really</h2>
          <p>
            Easy usability, solving real life problems. easy to implement. most of the cases has the fails and settings possibilities you right away need. never fails to impress.
          </p>
          <p className="author">Oliver Q,</p>
          <p className="job-title">Geschäftsführung Kreation/Art direction, Small-Business</p>
          <div className="stars">
            {[...Array(5)].map((_, i) => (
              <span key={i} className="star">⭐</span>
            ))}
          </div>
        </div>
      </div>
  </div>
  </div>
  </div>

     
        <CardContent>
  <input type="text" id="urlInput" placeholder="Enter URL" />

  <Button onClick={handleSearch} variant="contained" color="primary" disabled={loading}>
    Fetch Data
  </Button>
</CardContent>
 </Card>

    







      {loading && <CircularProgress size={50} className={classes.spinner} />}

      {error && <div className="error">{error}</div>}

      {!loading && internalLinksCount !== null && (
        <>












 <Typography variant="h4" component="div" gutterBottom>

      </Typography><br></br><br></br>

      <div className="cards-container">








      <Card className="custom-card">
          <CardContent className="card-content">
            {/* SVG Icon representing total crawled links */}
            <svg
              width="40" height="40"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="card-icon"
            >
              <rect x="2" y="12" width="5" height="10" fill="#007bff"/>
              <rect x="9" y="6" width="5" height="16" fill="#007bff"/>
              <rect x="16" y="3" width="5" height="19" fill="#007bff"/>
            </svg>
            <Link to="totalcrawledlinks" onClick={handleButtonClick} className="link-style">
              <Button className="custom-button">
                {totalCrawledLinks} Total Crawled Links
              </Button>
            </Link>
          </CardContent>
        </Card>










        <Card className="custom-card">
          <CardContent className="card-content">
            <svg
              width="40" height="40"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="card-icon"
            >
              <rect x="4" y="16" width="4" height="8" fill="#007bff"/>
              <rect x="10" y="12" width="4" height="12" fill="#007bff"/>
              <rect x="16" y="8" width="4" height="16" fill="#007bff"/>
            </svg>
            <Link to="internallinks" onClick={handleButtonClick} className="link-style">
              <Button className="custom-button">
                {internalLinksCount} Internal Links
              </Button>
            </Link>
          </CardContent>
        </Card>

        <Card className="custom-card">
  <CardContent className="card-content">
    {/* SVG Icon for External Links with color */}
    <svg
      width="40" height="40"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="card-icon external-links-icon"
    >
      <path d="M14 2v4h-2V4H6v16h8v-2H8V8h6v4h2V4h-2z" fill="#2196F3"/> {/* Blue color */}
      <path d="M17 10h-2v2h2v-2zm-4 0h-2v2h2v-2zm-4 0H7v2h2v-2zM7 14h10v2H7v-2zM7 18h10v2H7v-2z" fill="#2196F3"/> {/* Blue color */}
    </svg>
    <Link to="externallinks" onClick={handleButtonClick1} className="link-style">
      <Button className="custom-button">
        {externalLinksCount} External Links
      </Button>
    </Link>
  </CardContent>
</Card>


        <Card className="custom-card">
      <CardContent className="card-content">
        {/* SVG Icon representing meta tags */}
        <svg
          width="40" height="40"
          viewBox="0 0 24 24"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="card-icon"
        >
          <circle cx="12" cy="12" r="10" stroke="#007bff" strokeWidth="2"/>
          <line x1="7" y1="12" x2="17" y2="12" stroke="#007bff" strokeWidth="2"/>
          <line x1="12" y1="7" x2="12" y2="17" stroke="#007bff" strokeWidth="2"/>
        </svg>
        <Link to="metatags" onClick={handleButtonClick} className="link-style">
          <Button className="custom-button">
            {metaTagsCount} Meta Tags
          </Button>
        </Link>
      </CardContent>
    </Card>

    <Card className="custom-card">
      <CardContent className="card-content">
        {/* SVG Icon for backlinks */}
        <svg
          width="40" height="40"
          viewBox="0 0 24 24"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="card-icon"
        >
          <path d="M14.59 7.41L12 10l-2.59-2.59L6 10l6 6 6-6-2.59-2.59L12 10l-2.59-2.59L12 6l2.59 2.59L18 6l-4.59 4.59z" fill="#007bff"/>
        </svg>
        <Link to="backlinks" onClick={handleButtonClick} className="link-style">
          <Button className="custom-button">
            {backlinksCount} Backlinks
          </Button>
        </Link>
      </CardContent>
    </Card>

    <Card className="custom-card">
      <CardContent className="card-content">
        {/* SVG Icon for HTML Pages */}
        <svg
          width="40" height="40"
          viewBox="0 0 24 24"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="card-icon"
        >
          <rect x="4" y="4" width="16" height="16" stroke="#007bff" strokeWidth="2"/>
          <path d="M4 4h16v16H4V4zm2 2v12h12V6H6zm2 2h8v8H8V8z" fill="#007bff"/>
        </svg>
        <Link to="htmlpages" onClick={handleButtonClick} className="link-style">
          <Button className="custom-button">
            {htmlPagesCount} HTML Pages
          </Button>
        </Link>
      </CardContent>
    </Card>
    <Card className="custom-card">
      <CardContent className="card-content">
        {/* SVG Icon for Non-HTML Files */}
        <svg
          width="40" height="40"
          viewBox="0 0 24 24"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="card-icon"
        >
          <path d="M4 4h16v16H4V4zm2 2v12h12V6H6zm2 2h8v8H8V8z" fill="#2196F3"/>
          <path d="M6 6h12v12H6V6zm2 2h8v8H8V8z" fill="#2196F3"/>
        </svg>
        <Link to="nonhtmlfiles" onClick={handleButtonClick} className="link-style">
          <Button className="custom-button">
            {nonHtmlFilesCount} Non-HTML Files
          </Button>
        </Link>
      </CardContent>
    </Card>

    <Card className="custom-card">
      <CardContent className="card-content">
        {/* SVG Icon for Total Images */}
        <svg
          width="40" height="40"
          viewBox="0 0 24 24"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="card-icon"
        >
          <path d="M12 3C7.03 3 3 7.03 3 12s4.03 9 9 9 9-4.03 9-9-4.03-9-9-9zm0 16c-3.68 0-6.68-3-6.68-6.68S8.32 6.64 12 6.64 18.68 9.64 18.68 13.32 15.68 19 12 19zm-.68-9.64h-3.36v2.68h3.36v-2.68zm0-4.68h-3.36v2.68h3.36V6.68z" fill="#2196F3"/>
        </svg>
        <Link to="totalimages" onClick={handleButtonClick} className="link-style">
          <Button className="custom-button">
            {totalImages} Total Images
          </Button>
        </Link>
      </CardContent>
    </Card>
      </div>
   <br></br> <br></br> <br></br>


          <Button onClick={() => toggleLinks('internal')} variant="contained" color="secondary">
            {showLinks === 'internal' ? 'Hide' : 'Show'} Internal Links
          </Button>
          {showLinks === 'internal' && (
            <div>
              <h3>Internal Links</h3>
              <ul>
                {internalLinks.map((link, index) => (
                  <li key={index}>
                    <a href={link} target="_blank" rel="noopener noreferrer">{link}</a>
                  </li>
                ))}
              </ul>
            </div>
          )}

          <Button onClick={() => toggleLinks('external')} variant="contained" color="secondary">
            {showLinks === 'external' ? 'Hide' : 'Show'} External Links
          </Button>
          {showLinks === 'external' && (
            <div>
              <h3>External Links</h3>
              <ul>
                {externalLinks.map((link, index) => (
                  <li key={index}>
                    <a href={link} target="_blank" rel="noopener noreferrer">{link}</a>
                  </li>
                ))}
              </ul>
            </div>
          )}


<Button onClick={() => toggleLinks('canonical')} variant="contained" color="secondary">
            {showLinks === 'canonical' ? 'Hide' : 'Show'} canonical Links
          </Button>
          {showLinks === 'canonical' && (
            <div>
              <h3>canonical Links</h3>
              <ul>
                {canonicalLinks.map((link, index) => (
                  <li key={index}>
                    <a href={link} target="_blank" rel="noopener noreferrer">{link}</a>
                  </li>
                ))}
              </ul>
            </div>
          )}



<br></br><br></br><br></br>






          <div className="chart-container">
            <Grid container spacing={2}>
              <Grid item xs={12} md={4}>
                <Card>
                  <CardContent>
                    <h3>Broken Links Chart</h3>
                    <div ref={brokenLinksChartRef}>
                      <Pie data={brokenLinksData} />
                    </div>
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} md={4}>
                <Card>
                  <CardContent>
                    <h3>HTML Pages Chart</h3>
                    <div ref={htmlPagesChartRef}>
                      <Pie data={htmlPagesData} />
                    </div>
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} md={4}>
                <Card>
                  <CardContent>
                    <h3>Redirects Chart</h3>
                    <div ref={redirectsChartRef}>
                      <Pie data={redirectsData} />
                    </div>
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} md={4}>
                <Card>
                  <CardContent>
                    <h3>Protocol Chart</h3>
                    <div ref={protocolChartRef}>
                      <Pie data={protocolData} />
                    </div>
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} md={4}>
                <Card>
                  <CardContent>
                    <h3>Canonical Chart</h3>
                    <div ref={canonicalChartRef}>
                      <Pie data={canonicalData} />
                    </div>
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} md={10}>
                <Card>
                  <CardContent>
                    <h3>Line Chart</h3>
                    <div ref={lineChartRef}>
                      <Line data={lineData} />
                    </div>
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12} md={10}>
                <Card>
                  <CardContent>
                    <h3>Bar Chart</h3>
                    <div ref={barChartRef}>
                      <Bar data={barData} />
                    </div>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
          </div>

          <Button onClick={handleDownloadPDF} variant="contained" color="primary">
            Download PDF
          </Button>
        </>












      )}
      <div className="container">
        
        <div className="row">
        <div className="col-md-8">

      <MDBAccordion initialActive={1}>
  <MDBAccordionItem collapseId={1} headerTitle='What are internal links?'>
    <strong>Internal links</strong> are hyperlinks that point to other pages within the same domain. They are used to navigate between different pages of a website, helping users find related content and improving the site's overall usability and SEO.
  </MDBAccordionItem>
  
  <MDBAccordionItem collapseId={2} headerTitle='Why are internal links important for SEO?'>
    <strong>Internal links</strong> are crucial for SEO because they help search engines understand the structure of your website and the relationship between different pages. They can also distribute page authority and ranking power throughout the site, potentially improving the visibility of important pages in search results.
  </MDBAccordionItem>
  
  <MDBAccordionItem collapseId={3} headerTitle='How should I use internal links effectively?'>
    To use <strong>internal links</strong> effectively, follow these best practices:
    <ul>
      <li><strong>Use descriptive anchor text:</strong> Ensure the text used for links accurately describes the content of the target page.</li>
      <li><strong>Avoid over-linking:</strong> Don’t overuse internal links on a single page; focus on quality and relevance.</li>
      <li><strong>Link to relevant pages:</strong> Make sure the internal links are relevant to the content they are placed within.</li>
      <li><strong>Maintain a logical hierarchy:</strong> Structure your internal links to support a clear site hierarchy and navigation flow.</li>
    </ul>
  </MDBAccordionItem>
  
  <MDBAccordionItem collapseId={4} headerTitle='Can too many internal links harm my SEO?'>
    While internal linking is beneficial, excessive or irrelevant internal links can potentially harm SEO. It can lead to a poor user experience and dilute the relevance of your links. Aim for a balanced approach, focusing on quality and relevance rather than quantity.
  </MDBAccordionItem>
</MDBAccordion>


</div>
</div>
</div>

    </div>
  );
};

export default InternalLinkCounter;
